public class AntarService implements LaundryService{
    private boolean done; // field done


    @Override
    public String doWork() {
        this.done = true; // set done ke true karena service ini ditandai selesai dikerjakan
        return "Sedang mengantar...";
    }

    // getter untuk field done
    @Override
    public boolean isDone() {
        return this.done;
    }

    // harga service ini adalah 500/kg dengan ketentuan harga dasar sebanyak 2000.
    @Override
    public long getHarga(int berat) {
        return 500 * berat < 2000? 2000 : 500 * berat;
    }

    // dapatkan nama service
    @Override
    public String getServiceName() {
        return "Antar";
    }
}

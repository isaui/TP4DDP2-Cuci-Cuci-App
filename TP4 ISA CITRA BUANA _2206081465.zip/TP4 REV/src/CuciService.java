public class CuciService implements LaundryService{
    private boolean done; // field done
    @Override
    public String doWork() {
        this.done = true; // set done ke true karena service ini ditandai selesai dikerjakan
        return "Sedang mencuci...";
    }

    // getter field done
    @Override
    public boolean isDone() {
        return this.done;
    }

    // harga service cuci = 0 , mengingat sudah menjadi service dasar yang include di paket laundry
    @Override
    public long getHarga(int berat) {
        // TODO
        return 0;
    }

    // dapatkan nama service
    @Override
    public String getServiceName() {
        return "Cuci";
    }
}

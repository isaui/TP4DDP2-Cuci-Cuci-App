import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;


/*
* EmployeeGUI adalah inheritor (child class) dari kelas MemberGUI karena GUI nya
* mirip kecuali pada bagian center perlu dilakukan override agar
* implementasinya berbeda karena menu yang tersedia maupun ciri khas yang ada
* di akun employee dan akun member berbeda */
public class EmployeeGUI extends MemberGUI{
    private final String MENYAPA_KARYAWAN = "<html>Selamat bekerja,Kawan-kawan!</html>";
    private JPanel panelNotaKedua;
    protected JLabel labelNotif;

    public EmployeeGUI(Component parent, Employee employee){
        super(parent,employee);
        createKerjakanPanelNota();

    }

    /*
    * Mengisi pengingat kepada employee
    * berapa tugas yang belum mereka selesaikan*/
    public String notif(){
        StringBuilder notif = new StringBuilder();
        notif.append("<html><p align=\"center\">Hai, <b>"+getLoginMember().getNama()+"</b>!<br>");
        int j = 0;
        for(int i = 0; i < NotaManager.notaList.length;i++){
            if(NotaManager.notaList[i] != null){
                if(! NotaManager.notaList[i].isDone()) j++;
            }
        }
        if(j != 0) notif.append("Kamu memiliki "+j+" tugas yang belum diselesaikan</p></html>");
        else notif.append("Selamat, kamu telah menyelesaikan semua tugasmu hari ini</p></html>");
        return notif.toString();
    }

    /*
    * Perlu dioverride untuk membedakan menu atau tampilan
    * antara akun employee dan member*/
    @Override
    void customizeMidPanel() {
        JPanel panelHome = new JPanel(new GridBagLayout());
        JLabel labelSapaan = new JLabel(MENYAPA_KARYAWAN);
        labelSapaan.setForeground(Color.white);
        labelSapaan.setFont(new Font("Segou UI", Font.BOLD, 36));
        labelNotif = new JLabel(notif());
        labelNotif.setForeground(Color.white);
        labelNotif.setFont(new Font("Times New Roman", Font.TRUETYPE_FONT, 26));
        panelHome.setVisible(true);
        panelHome.setOpaque(false);
        panelHome.add(labelSapaan, new GridBagConstraints(0,0,2,2,
                0,0,GridBagConstraints.WEST,GridBagConstraints.NONE,new
                Insets(30,100,30,0),0
                , 0 ));
        panelHome.add(new CarouselPanel("salary-increment.png",
                "employee-performance-evaluation.png","beach-trip.png" ), new GridBagConstraints(0,2,4,4, 0,0,GridBagConstraints.NORTH,GridBagConstraints.NONE,
                new Insets(0,0,0,0),0,0));
        JPanel panelNotif = new JPanel();
        panelNotif.add(labelNotif);
        panelNotif.setOpaque(false);
        panelNotif.setPreferredSize(new Dimension(800,100));
        panelNotif.setMinimumSize(new Dimension(800,100));
        panelHome.add(panelNotif, new GridBagConstraints(0,6,4,
                1,0,0,GridBagConstraints.CENTER,GridBagConstraints.NONE,new Insets(0,50,0,0),0
                , 0 ));
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        panel.add((new IconPane(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        createKerjakanPanelNota();
                        openKerjakanPanelNota();

                    }
                }, new ImageIcon("mulai_laundry.png").getImage(), 60, 60, "Begin working")),
                LoginPage.createConstraint(0,2,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, 0, 0, 0,0,
                        new Insets(0,0,0,parent.getWidth()/11)));

        panel.add((new IconPane(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        createPanelNota();
                        openPanelNota();

                    }
                }, new ImageIcon("list.png").getImage(), 60, 60, "Laundry list")),
                LoginPage.createConstraint(1,2,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, 0, 0, 0,0,
                        new Insets(0,0,0,parent.getWidth()/11)));
        panelHome.add(panel, new GridBagConstraints(0,7,4,1,0,0
                ,GridBagConstraints.CENTER,GridBagConstraints.NONE,new Insets(0,0,0,0),0
                , 0 ));
        panel.add((new IconPane(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        System.out.println("dont try this at home");

                    }
                }, new ImageIcon("resign.png").getImage(), 60, 60, "Resign")),
                LoginPage.createConstraint(2,2,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, 0, 0, 0,0,
                        new Insets(0,0,0,parent.getWidth()/11)));
        panelHome.add(panel, new GridBagConstraints(0,7,4,1,0,0
                ,GridBagConstraints.CENTER,GridBagConstraints.NONE,new Insets(0,0,0,0),0
                , 0 ));

        this.midPanel.add(panelHome);
        midComponent.put("panel utama", panelHome);

    }

    /*
    * Implementasi button mulai laundry apabila ditekan maka akan menampilkan halaman baru
    * khusus untuk melakukan kegiatan laundry*/
    void openKerjakanPanelNota(){
        Component kerjakanPanelNota = midComponent.get("panel nota executable");
        for(Component component : midComponent.values()){
            if(component.equals(kerjakanPanelNota)) component.setVisible(true);
            else component.setVisible(false);
        }
        revalidate();
        repaint();
    }

    /*
    * Pembuatan halaman baru untuk melakukan kegiatan laundry.
    *  Halaman ini tidak menampilkan nota yang perlu dikerjakan.
    * Pengerjaan nota dapat dilakukan secara manual atau satu satu
    * maupun langsung sekaligus*/
    void createKerjakanPanelNota(){
        panelNotaKedua = new JPanel(new BorderLayout());
        JPanel centerPanelOnTop = new JPanel();

        JPanel panelInformasi = new JPanel();
        panelInformasi.setPreferredSize(new Dimension(300,200));
        panelInformasi.setMinimumSize(new Dimension(300,200));
        panelInformasi.setSize(new Dimension(300,200));
        panelInformasi.setBackground(Color.white);
        panelInformasi.setVisible(true);
        JLabel labelInformasi = new JLabel("INFORMASI");
        labelInformasi.setFont(new Font("Serif", Font.PLAIN, 36));
        labelInformasi.setForeground(Color.white);
        panelInformasi.add(labelInformasi);
        panelNotaKedua.setOpaque(false);
        panelInformasi.setBackground(new Color(29,38,125));
        panelInformasi.setVisible(true);
        centerPanelOnTop.setOpaque(false);


        JPanel panelNotaData = new JPanel(new GridBagLayout());
        panelNotaData.setBackground(Color.black);
        panelNotaData.setOpaque(false);
        //panelNotaData.setPreferredSize(new Dimension(1366, 800));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        JScrollPane jScrollPanelNota = new JScrollPane(panelNotaData);
        jScrollPanelNota.setOpaque(false);

        LoginPage.ButtonMelengkung buttonMelengkung = new LoginPage.ButtonMelengkung(30,50,"Informasi");
        buttonMelengkung.setOpaque(false);
        buttonMelengkung.setBackground(new Color(212,172,252));
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setMaximumSize(new Dimension(500,300));
        centerPanelOnTop.setLayout(new BoxLayout(centerPanelOnTop, BoxLayout.Y_AXIS));
        centerPanelOnTop.add(jScrollPanelNota);
        centerPanelOnTop.setOpaque(false);
        JFrame frameT = new JFrame();
        frameT.setSize(500,400);
        frameT.setContentPane(panelInformasi);
        frameT.setResizable(false);
        buttonMelengkung.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frameT.setVisible(true);
            }
        });

        jScrollPanelNota.getViewport().setOpaque(false);
        jScrollPanelNota.setBorder(null);
        jScrollPanelNota.getHorizontalScrollBar().setOpaque(false);
        jScrollPanelNota.getHorizontalScrollBar().setBorder(null);
        jScrollPanelNota.getHorizontalScrollBar().setBackground(new Color(212,172,252));
        jScrollPanelNota.getVerticalScrollBar().setBlockIncrement(128);
        jScrollPanelNota.getVerticalScrollBar().setUnitIncrement(16);
        jScrollPanelNota.getHorizontalScrollBar().setVisible(false);
        jScrollPanelNota.getVerticalScrollBar().setVisibleAmount(30);
        jScrollPanelNota.setPreferredSize(new Dimension(1680, 570));
        jScrollPanelNota.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        panelNotaData.setOpaque(false);
        panelNotaData.setMinimumSize(new Dimension(1000,700));
        jScrollPanelNota.setAutoscrolls(true);

        jScrollPanelNota.getVerticalScrollBar().setOpaque(false);
        jScrollPanelNota.getVerticalScrollBar().setBackground(Color.black);
        jScrollPanelNota.setVisible(true);
        jScrollPanelNota.getVerticalScrollBar().setUI(new BasicScrollBarUI(){
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(29,38,125);
                this.thumbHighlightColor = new Color(29,38,125);
                this.trackColor = new Color(0,0,0,0);
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                JButton button = super.createDecreaseButton(orientation);
                button.setBackground(new Color(29,38,125));
                return button;
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                JButton button = super.createIncreaseButton(orientation);
                button.setBackground(new Color(29,38,125));
                return button;
            }
        });
        jScrollPanelNota.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        ArrayList<NotaBuilder> notaBuilders = new ArrayList<>();
        gbc.gridx = 0;
        gbc.gridy = 0;
        int j = 0;
        for (int i = 0; i < NotaManager.notaCounter; i++){
            if(!NotaManager.notaList[i].isDone()) {
                gbc.gridx = j % 5;
                gbc.gridy = j / 5;
                j++;
                notaBuilders.add(new NotaBuilderExecutable
                        (NotaManager.notaList[i], 180, 180, NotaManager.notaList[i].getMember(), this));
            }
        }
        NotaBuilder.createNotaBuilder(notaBuilders, panelNotaData);

        frameT.setLocationRelativeTo(panelNotaKedua);
        panelNotaKedua.add(centerPanelOnTop,BorderLayout.CENTER);
        JLabel label = new JLabel("Nota yang perlu dikerjakan");
        label.setForeground(Color.white);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setFont(new Font("Serif", Font.LAYOUT_NO_LIMIT_CONTEXT,48));
        label.setBorder(new EmptyBorder(0,0,20,0));

        panel.add(label, new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.CENTER,GridBagConstraints.NONE,
                new Insets(0,0,0,10),0,0));
        JPanel childPanel = new JPanel(new GridBagLayout());
        childPanel.setOpaque(false);
        childPanel.setVisible(true);
        panel.add(childPanel,new GridBagConstraints(1,0,1,1,0,0,GridBagConstraints.CENTER,GridBagConstraints.NONE,
                new Insets(0,0,0,10),0,0));
        childPanel.add(buttonMelengkung, new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.CENTER,GridBagConstraints.NONE,
                new Insets(0,0,0,10),0,0));

        LoginPage.ButtonMelengkung buttonkerjakanSemua = new LoginPage.ButtonMelengkung(30,50,
               "Kerjakan Semua");
        childPanel.add(buttonkerjakanSemua, new GridBagConstraints(1,0,1,1,0,0,GridBagConstraints.CENTER,GridBagConstraints.NONE,
                new Insets(0,0,0,10),0,0));
        buttonkerjakanSemua.setBackground(new Color(212,172,252));
        buttonkerjakanSemua.setVisible(true);
        buttonkerjakanSemua.setPreferredSize(new Dimension(160,30));
        buttonkerjakanSemua.setOpaque(false);
        buttonkerjakanSemua.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                for(NotaBuilder graphic : notaBuilders){
                    graphic.setVisible(false);
                }
                new ResultLaundry(MainMenu.getInstance().getLoginManager().getEmployeeSystem().bekerja());
                labelNotif.setText(notif());
                //Component panel = midComponent.remove("panel utama");
               // midPanel.remove(panel);
               // customizeMidPanel();
              //  midPanel.revalidate();
              //  midPanel.repaint();


            }
        });
        panel.setOpaque(false);
        panelNotaKedua.add(panel, BorderLayout.NORTH);
        panelNotaKedua.setVisible(false);
        midComponent.put("panel nota executable", panelNotaKedua);
        midPanel.add(panelNotaKedua);
    }


    /*
    * Membuat halaman untuk menampilkan segala
    *  nota yang tersimpan di Nota Manager.*/
    @Override
    void createPanelNota() {
        panelNota = new JPanel(new BorderLayout());
        JPanel centerPanelOnTop = new JPanel();

        JPanel panelInformasi = new JPanel();
        panelInformasi.setPreferredSize(new Dimension(300, 200));
        panelInformasi.setMinimumSize(new Dimension(300, 200));
        panelInformasi.setSize(new Dimension(300, 200));
        panelInformasi.setBackground(Color.white);
        panelInformasi.setVisible(true);
        JLabel labelInformasi = new JLabel("INFORMASI");
        labelInformasi.setFont(new Font("Serif", Font.PLAIN, 36));
        labelInformasi.setForeground(Color.white);
        panelInformasi.add(labelInformasi);
        panelNota.setOpaque(false);
        panelInformasi.setBackground(new Color(29, 38, 125));
        panelInformasi.setVisible(true);
        centerPanelOnTop.setOpaque(false);


        JPanel panelNotaData = new JPanel(new GridBagLayout());
        panelNotaData.setBackground(Color.black);
        panelNotaData.setOpaque(false);
        //panelNotaData.setPreferredSize(new Dimension(1366, 800));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        JScrollPane jScrollPanelNota = new JScrollPane(panelNotaData);
        jScrollPanelNota.setOpaque(false);

        LoginPage.ButtonMelengkung buttonMelengkung = new LoginPage.ButtonMelengkung(30, 50, "Informasi");
        buttonMelengkung.setOpaque(false);
        buttonMelengkung.setBackground(new Color(212, 172, 252));
        JPanel panel = new JPanel();
        panel.setMaximumSize(new Dimension(500, 300));
        centerPanelOnTop.setLayout(new BoxLayout(centerPanelOnTop, BoxLayout.Y_AXIS));
        centerPanelOnTop.add(jScrollPanelNota);
        centerPanelOnTop.setOpaque(false);
        JFrame frameT = new JFrame();
        frameT.setSize(500, 400);
        frameT.setContentPane(panelInformasi);
        frameT.setResizable(false);
        buttonMelengkung.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frameT.setVisible(true);
            }
        });
        jScrollPanelNota.setPreferredSize(new Dimension(1680, 570));
        jScrollPanelNota.getViewport().setOpaque(false);
        jScrollPanelNota.setBorder(null);
        jScrollPanelNota.getHorizontalScrollBar().setOpaque(false);
        jScrollPanelNota.getHorizontalScrollBar().setBorder(null);
        jScrollPanelNota.getHorizontalScrollBar().setBackground(new Color(212, 172, 252));
        jScrollPanelNota.getVerticalScrollBar().setBlockIncrement(128);
        jScrollPanelNota.getVerticalScrollBar().setUnitIncrement(16);
        jScrollPanelNota.getHorizontalScrollBar().setVisible(false);
        jScrollPanelNota.getVerticalScrollBar().setVisibleAmount(30);
        jScrollPanelNota.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        panelNotaData.setOpaque(false);
        jScrollPanelNota.setAutoscrolls(true);
        jScrollPanelNota.getVerticalScrollBar().setOpaque(false);
        jScrollPanelNota.getVerticalScrollBar().setBackground(Color.black);
        jScrollPanelNota.setVisible(true);
        jScrollPanelNota.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(29, 38, 125);
                this.thumbHighlightColor = new Color(29, 38, 125);
                this.trackColor = new Color(0, 0, 0, 0);
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                JButton button = super.createDecreaseButton(orientation);
                button.setBackground(new Color(29, 38, 125));
                return button;
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                JButton button = super.createIncreaseButton(orientation);
                button.setBackground(new Color(29, 38, 125));
                return button;
            }
        });
        jScrollPanelNota.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        ArrayList<NotaBuilder> notaBuilders = new ArrayList<>();
        gbc.gridx = 0;
        gbc.gridy = 0;
        Nota temp = new Nota(null, 25, "Reguler", "22/06/2014");
        int j = 0;
        for (int i = 0; i < NotaManager.notaCounter; i++) {
            gbc.gridx = i % 5;
            gbc.gridy = i / 5;
            notaBuilders.add(new NotaBuilder(NotaManager.notaList[i], 180, 180, NotaManager.notaList[i].getMember()));
        }
        NotaBuilder.createNotaBuilder(notaBuilders, panelNotaData);
        jScrollPanelNota.revalidate();
        frameT.setLocationRelativeTo(panelNota);
        panelNota.add(centerPanelOnTop, BorderLayout.CENTER);
        JLabel label = new JLabel("Nota Tersimpan ");
        label.setForeground(Color.white);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setFont(new Font("Serif", Font.LAYOUT_NO_LIMIT_CONTEXT, 48));
        label.setBorder(new EmptyBorder(0, 0, 20, 0));
        panel.add(label);
        panel.add(buttonMelengkung);
        panel.setOpaque(false);
        panelNota.add(panel, BorderLayout.NORTH);
        panelNota.setVisible(false);
        midComponent.put("panel nota", panelNota);
        midPanel.add(panelNota);
    }
    }

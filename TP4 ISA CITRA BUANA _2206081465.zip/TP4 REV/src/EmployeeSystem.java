import java.util.Arrays;

public class EmployeeSystem extends SystemCLI {

    /**
     * Membuat object baru EmployeeSystem dan mendaftarkan Employee pada CuciCuci
     */

    public EmployeeSystem() {
        memberList = new Member[]{
                new Employee("Dek Depe", "akuDDP"),
                new Employee("Depram", "musiktualembut"),
                new Employee("Lita Duo", "gitCommitPush"),
                new Employee("Ivan Hoshimachi", "SuamiSahSuisei"),
        };
    }

    /**
     * Memproses pilihan dari employee yang masuk ke sistem ini sesuai dengan menu specific.
     *
     * @param choice -> pilihan pengguna.
     * @return true jika user log.
     */
    @Override
    protected boolean processChoice(int choice) {
        boolean logout = false;
        if(choice == 1) bekerja(); // lakukan pekerjaan
        else if(choice == 2) displayListNota(); // display status seluruh nota yang tersimpan di notaList
        else if(choice == 3) logout = true; // logout
        return logout;
    }

    /*
     * lakukan iterasi terhadap notaList kemudian jalankan method kerjakan
     * untuk setiap nota yang tersimpan di notaList tersebut*/
    protected String bekerja(){
        StringBuilder builder = new StringBuilder();
      //  System.out.println(String.format("Stand back! %s beginning to nyuci!", loginMember.getNama()));
        for (int i = 0; i < NotaManager.notaList.length; i++){
            if(NotaManager.notaList[i] != null){
                builder.append(NotaManager.notaList[i].kerjakan()+"<br>");
            }
        }
        return builder.toString();
    }

    /*
     * lakukan iterasi terhadap notaList kemudian
     * display status seluruh nota yang tersimpan di notaList */
    protected void displayListNota(){
        for(int i = 0; i < NotaManager.notaList.length; i++){
            if(NotaManager.notaList[i] != null){
                System.out.println(String.format("%s", NotaManager.notaList[i].getNotaStatus()));
            }
        }
    }
    protected Employee addEmployee(String nama, String password){
        for (Member member : memberList){
            if(member.equals(nama)) return  null;
        }
        if(memberPointer == memberList.length)
            memberList = Arrays.copyOf(memberList, memberList.length * 2);
        Employee employee = new Employee(nama, password);
        memberList[memberPointer++] = employee;
        return  employee;
    }

    /**
     * Displays specific menu untuk Employee.
     */
    // display specific menu untuk Employee
    @Override
    protected void displaySpecificMenu() {
        System.out.println("1. It's nyuci time");
        System.out.println("2. Display List Nota");
        System.out.println("3. Logout");
    }
}




public class LoginManager {
    private final EmployeeSystem employeeSystem;
    private final MemberSystem memberSystem;

    public LoginManager(EmployeeSystem employeeSystem, MemberSystem memberSystem) {
        this.employeeSystem = employeeSystem;
        this.memberSystem = memberSystem;
    }

    public EmployeeSystem getEmployeeSystem() {
        return employeeSystem;
    }

    /**
     * Method mapping dari ke SystemCLI yang sesuai.
     *
     * @param id -> ID dari user yang akan menggunakan SystemCLI
     * @return SystemCLI object yang sesuai dengan ID, null if  ID tidak ditemukan.
     */
    public SystemCLI getSystem(String id){
        if(memberSystem.isMemberExist(id)){
            return memberSystem;
        }
        if(employeeSystem.isMemberExist(id)){
            return employeeSystem;
        }
        return null;
    }

    /**
     * Mendaftarkan member baru dengan informasi yang diberikan.
     *
     * @param nama -> Nama member.
     * @param noHp -> Nomor handphone member.
     * @param password -> Password akun member.
     * @return Member object yang berhasil mendaftar, return null jika gagal mendaftar.
     */
    public Member register(String nama, String noHp, String password) {

        String id = generateId(nama,noHp);
        if(memberSystem.isMemberExist(id)) return null;
        Member memberToBeRegistered = new Member(nama,id,password);
        memberSystem.addMember(memberToBeRegistered);
        return memberToBeRegistered;
    }
    public Member registerAsEmployee(String nama, String noHp, String password){
        Member member = employeeSystem.addEmployee(nama, password);
        return member;
    }

    // generate id member berdasarkan nama depan yang sudah
    // diuppercase dan nomor hp. Kombinasi keduanya akan menghasilkan checksum tersendiri.
    // id terdiri dari nama depan-noHp-checkSum
    public String generateId(String nama, String noHp){
        nama = nama.split(" ")[0].toUpperCase();
        int checkSum = generateCheckSum(nama+"-"+noHp, new Integer[37]) %100;
        String checkSumString = checkSum < 10 ? "0" + checkSum : String.valueOf(checkSum);
        return nama + "-"+noHp+"-"+checkSumString;
    }

    // method rekursif untuk menghasilkan checksum sama seperti di TP1 dan TP2.
    public int generateCheckSum(String text, Integer[] memo){
        if(text.isEmpty() || text.isBlank()){
            return  0;
        }
        char startChar = text.charAt(0);
        int index = Character.isLetter(startChar)? (int) startChar -55 :
                Character.isDigit(startChar)? (int) startChar - 48 : 36;
        if(memo[index] != null){
            return  memo[index];
        }
        int current = Character.isLetter(startChar)?(startChar - 'A') + 1:
                Character.isDigit(startChar)? startChar - '0' : 7;
        int result = current + generateCheckSum(text.substring(1), memo);
        memo[index] = current;
        return  result;
    }

}

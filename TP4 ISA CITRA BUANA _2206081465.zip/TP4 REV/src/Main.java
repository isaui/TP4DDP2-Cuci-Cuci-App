import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.MouseInputListener;
import javax.swing.plaf.ScrollBarUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.text.BadLocationException;
import javax.swing.text.html.HTMLDocument;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.*;
import java.util.Timer;


/*
* Kelas untuk menampilkan halaman laundry untuk member.
* Halaman tersebut muncul setelah button Laundry Order ditekan.
* Kelas ini juga merupakan wadah bagi panel-panel lain yang digunakan
* menampilkan informasi pemesanan paket laundry*/
class LaundryOrderPanel extends JPanel{

    LoginPage.ButtonMelengkung btnGeserKiri, btnGeserKanan;
    private ArrayList<BiggerCarousel> carousels = new ArrayList<>();
    private JPanel panelSetPackage, panelStepbyStep;

    private static  final int BASE_HARGA_PAKET_REGULER = 7000;
    private  static final int BASE_HARGA_PAKET_FAST = 10000;
    private static final int BASE_HARGA_PAKET_EXPRESS = 12000;


    Component parent;
    LaundryOrderPanel getInstance(){
        return this;
    }

    /*
    * Static class yang berfungsi menyimpan data informasi
    * penambahan order laundry*/
    static class PanelDataLaundry extends JPanel{
        BiggerCarousel paket;

        JLabel labelBerat, labelAddService, labelPaket;
        JPanel tablePanel;
        private PropertyChangeSupport pcs = new PropertyChangeSupport(this);
        LoginPage.RoundedTextField roundedTextField;
        Component parent;
        private  int harga;

        BiggerCarousel setrikaService, deliveryService;

        PanelDataLaundry(BiggerCarousel paket, Component parent){
            this.parent = parent;
            this.paket = paket;
            this.harga = paket.getName().equalsIgnoreCase("REGULER")? LaundryOrderPanel.BASE_HARGA_PAKET_REGULER :
                    paket.getName().equalsIgnoreCase("FAST")? LaundryOrderPanel.BASE_HARGA_PAKET_FAST :
                            BASE_HARGA_PAKET_EXPRESS;
            this.roundedTextField = new LoginPage.RoundedTextField(10);
            this.roundedTextField.setPreferredSize(new Dimension(20, 30));
            this.setLayout(new GridBagLayout());
            this.labelBerat = new JLabel("Enter weight (in Kg): ");
            this.labelBerat.setFont(new Font("Tahoma", Font.PLAIN, 24));
            this.setVisible(true);
            this.setOpaque(false);
            this.labelAddService = new JLabel("Add additional services");
            this.labelAddService.setFont(new Font("Tahoma", Font.PLAIN, 24));
            this.labelPaket = new JLabel(paket.getName() + " Package");
            this.labelPaket.setFont(new Font("Tahoma", Font.ROMAN_BASELINE, 36));
            this.labelPaket.setForeground(Color.white);
            this.labelAddService.setForeground(Color.white);
            this.labelBerat.setForeground(Color.white);
            this.tablePanel = new JPanel(new GridBagLayout());
            tablePanel.setBackground(new Color(29,38,125));
            tablePanel.setPreferredSize(new Dimension(700 ,500));
            tablePanel.setMaximumSize(new Dimension(700, 500));


            JPanel jPanel = new JPanel(new GridBagLayout());
            jPanel.setOpaque(false);
            jPanel.add(labelPaket, new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.NORTH,
                    GridBagConstraints.NONE, new Insets(0,0,0,0), 0, 0));
            jPanel.add(paket, new GridBagConstraints(0,1,1,1,0,0,GridBagConstraints.NORTH,
                    GridBagConstraints.NONE, new Insets(20,0,0,0), 0, 0));

            LoginPage.ButtonMelengkung btn = new LoginPage.ButtonMelengkung(30,50,
                    "Process", new Dimension(280, 33));

            setrikaService = new BiggerCarousel(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    Image image, resizedImage;
                    boolean oldVal = setrikaService.aktif;
                    if(setrikaService.aktif){
                        setrikaService.aktif = false;
                        image = new ImageIcon("ironingservice.png").getImage();
                         resizedImage = image.getScaledInstance(150,150,Image.SCALE_SMOOTH) ;
                    } else {
                        setrikaService.aktif = true;
                        image = new ImageIcon("ironingserviceyes.png").getImage();
                        resizedImage = image.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                    }
                    pcs.firePropertyChange("GANTI_HARGA_SETRIKA", oldVal,setrikaService.aktif);
                    setrikaService.removeAll();
                    setrikaService.add(new JLabel(new ImageIcon(resizedImage)));
                    setrikaService.revalidate();
                    setrikaService.repaint();
                }
            },"Setrika", new ImageIcon("ironingservice.png").getImage(),
                    150, 150);
            deliveryService = new BiggerCarousel(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    Image image, resizedImage;
                    boolean oldVal = deliveryService.aktif;
                    if(deliveryService.aktif){
                        deliveryService.aktif = false;
                        image = new ImageIcon("deliveryservice.png").getImage();
                        resizedImage = image.getScaledInstance(150,150,Image.SCALE_SMOOTH) ;
                        //pcs.firePropertyChange("GANTI_HARGA_DELIVERY", oldVal, deliveryService.aktif);
                    } else {
                        deliveryService.aktif = true;
                        image = new ImageIcon("deliveryserviceyes.png").getImage();
                        resizedImage = image.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                      //  pcs.firePropertyChange("GANTI_HARGA_DELIVERY", oldVal, deliveryService.aktif);
                    }
                    pcs.firePropertyChange("GANTI_HARGA_DELIVERY", oldVal, deliveryService.aktif);
                    deliveryService.removeAll();
                    deliveryService.add(new JLabel(new ImageIcon(resizedImage)));
                    deliveryService.revalidate();
                    deliveryService.repaint();
                }
            },"Delivery", new ImageIcon("deliveryservice.png").getImage(), 150, 150);

            JPanel panel = new JPanel(new GridBagLayout());
            panel.add(labelAddService,  new GridBagConstraints(0,0,2,1,0,0,GridBagConstraints.CENTER,
                    GridBagConstraints.NONE, new Insets(0,0,0,0), 0, 0));
            panel.add(setrikaService, new GridBagConstraints(0,1,1,1,0,0,GridBagConstraints.CENTER,
                    GridBagConstraints.NONE, new Insets(22,0,0,8), 0, 0));
            panel.add(deliveryService, new GridBagConstraints(1,1,1,1,0,0,GridBagConstraints.CENTER,
                    GridBagConstraints.NONE, new Insets(22,0,0,8), 0, 0));
            panel.setOpaque(false);

            roundedTextField.getDocument().addDocumentListener(new DocumentListener() {
                @Override
                public void insertUpdate(DocumentEvent e) {
                    pcs.firePropertyChange("GANTI_BERAT", 0, 1);
                }

                @Override
                public void removeUpdate(DocumentEvent e) {
                    pcs.firePropertyChange("GANTI_BERAT", 0, 1);
                }

                @Override
                public void changedUpdate(DocumentEvent e) {
                    pcs.firePropertyChange("GANTI_BERAT", 0, 1);
                }
            });
            JLabel label = new JLabel("Calculate estimated price");
            label.setFont(new Font("Tahoma", Font.PLAIN, 24));
            label.setForeground(Color.white);
            LoginPage.RoundedTextField priceField = new LoginPage.RoundedTextField(20);
            priceField.setPreferredSize(new Dimension(20,30));
            JPanel anotherPanel = new JPanel(new GridBagLayout());
            anotherPanel.add(labelBerat, new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.CENTER,
                    GridBagConstraints.VERTICAL, new Insets(0,0,0,0), 0, 0));
            anotherPanel.add(roundedTextField, new GridBagConstraints(0,1,1,1,0,0,GridBagConstraints.CENTER,
                    GridBagConstraints.NONE, new Insets(10,0,0,0), 0, 0));
            anotherPanel.add(label,new GridBagConstraints(0,2,1,1,0,0,GridBagConstraints.CENTER,
                    GridBagConstraints.NONE, new Insets(10,0,0,0), 0, 0) );
            anotherPanel.add(priceField,new GridBagConstraints(0,3,1,1,0,0,GridBagConstraints.CENTER,
                    GridBagConstraints.NONE, new Insets(10,0,0,0), 0, 0) );
            anotherPanel.setOpaque(false);
            pcs.addPropertyChangeListener(new PropertyChangeListener() {
                @Override
                public void propertyChange(PropertyChangeEvent evt) {
                    if(evt.getPropertyName().equals("GANTI_BERAT")||evt.getPropertyName().equals("GANTI_HARGA_SETRIKA")
                            ||evt.getPropertyName().equals("GANTI_HARGA_DELIVERY")){
                        System.out.println("destination activate-> "+deliveryService.aktif);
                        boolean setrikaAdded = setrikaService.aktif;
                        boolean destinationAdded = deliveryService.aktif;
                        try {
                            int berat = Integer.parseInt(roundedTextField.getText());
                            int price = harga * berat;
                            ;
                            if (setrikaAdded) price += 1000 * berat;
                            if (destinationAdded) price += berat < 4 ? 2000 : 500 * berat;
                            priceField.setText(String.valueOf(price));
                        } catch (Exception exception){
                            priceField.setText("0");
                        }
                    }
                }
            });
            priceField.setEnabled(false);
            priceField.setForeground(Color.BLACK);
            priceField.setFont(new Font("Segoe UI", Font.ROMAN_BASELINE, 18));



            tablePanel.add(jPanel, new GridBagConstraints(0,0,1,2,0,0,GridBagConstraints.NORTH,
                    GridBagConstraints.NONE, new Insets(0,0,0,20), 0, 0));
            tablePanel.add(panel, new GridBagConstraints(1,0,1,1,0,0,GridBagConstraints.NORTH,
                    GridBagConstraints.NONE, new Insets(0,0,0,0), 0, 0));
            tablePanel.add(anotherPanel, new GridBagConstraints(1,1,1,1,0,0,GridBagConstraints.NORTH,
                    GridBagConstraints.NONE, new Insets(10,0,0,0), 0, 0));
            tablePanel.add(btn,new GridBagConstraints(0,2,2,1,0,0,GridBagConstraints.CENTER,
                    GridBagConstraints.NONE, new Insets(20,0,0,0), 0, 0) );
            this.add(tablePanel);
            btn.setBackground(new Color(212,172,252));
            btn.setOpaque(false);
           // btn.setForeground(Color.white);
            btn.setFont(new Font("Verdana", Font.TRUETYPE_FONT, 120));
            btn.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {


                    LaundryOrderPanel laundryOrderPanel = (LaundryOrderPanel) parent;
                    MemberGUI parent = (MemberGUI)  laundryOrderPanel.parent;
                    ValidatorAddLaundry validator = new ValidatorAddLaundry(parent.getLoginMember(),
                            labelPaket.getText().split(" ")[0],roundedTextField.getText(),NotaManager.fmt.format(NotaManager.cal.getTime()),
                            setrikaService.aktif, deliveryService.aktif
                            );
                    boolean valid = validator.cekValidasi();
                    if(!valid) {
                        OptionPaneCustom.showErrorDialogRev("Warning", "You have entered a non-digit character in the weight input for laundry." +
                                " Please enter the weight in kilograms (kg) without punctuation or other characters.");
                        return; // do something
                    }
                    Nota nota = validator.createValidNota();
                    if(nota == null) return;
                    NotaManager.addNota(nota);
                    parent.getLoginMember().addNota(nota);
                    parent.midPanel.remove(laundryOrderPanel);
                    tablePanel.setVisible(false);
                    remove(tablePanel);
                    parent.midComponent.remove("laundry order panel");
                    parent.midComponent.get("panel utama").setVisible(true);
                    parent.createPanelNota();
                    parent.midPanel.revalidate();
                    parent.midPanel.repaint();

                    OptionPaneCustom.showAcceptedDialogRev("Success", "Successfully generate an laundry order");

                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    btn.setBackground(new Color(250, 152, 132));
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    btn.setBackground(new Color(212,172,252));
                }
            });
        }
    }

    void settingPanelPenyelesaian(BiggerCarousel carousel){
        this.removeAll();
        this.add(new PanelDataLaundry(carousel, this));
        revalidate();
        repaint();
    }
    LaundryOrderPanel(Component parent){
        this.parent = parent;
        this.carousels.add(new BiggerCarousel(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                settingPanelPenyelesaian(new BiggerCarousel("Reguler", new ImageIcon("reg.png").getImage(),
                        300,300));
            }
        },"Reguler", new ImageIcon("reguler.png").getImage(), 300, 300) );

        this.carousels.add(new BiggerCarousel(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                settingPanelPenyelesaian(new BiggerCarousel("Fast", new ImageIcon("fst.png").getImage(),
                        300,300));
            }
        },"Fast", new ImageIcon("fast.png").getImage(), 300, 300) );
        this.carousels.add(new BiggerCarousel(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                settingPanelPenyelesaian(new BiggerCarousel("Express", new ImageIcon("exp.png").getImage(),
                        300, 300));
            }
        },"Express", new ImageIcon("express.png").getImage(), 300, 300) );
        this.panelSetPackage = new JPanel();
        //this.panelStepbyStep = new JPanel();
        this.panelSetPackage.setLayout(new GridBagLayout());
       // this.add(panelStepbyStep, new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.CENTER,
              //  GridBagConstraints.HORIZONTAL, new Insets(0,0,0,0), 0, 0));
        this.add(panelSetPackage,new GridBagConstraints(0,1,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(0,0,0,0), 0, 0) );

        customizePanelSetPackage();
        this.setVisible(true);
        this.setOpaque(false);
    }

    /*
    * Kustomisasi ketika memilih jenis paket.
    * Method ini menampilkan carousel yang dapat bergeser untuk
    * memberi informasi tambahan kepada pengguna*/
    void customizePanelSetPackage(){
        panelSetPackage.setOpaque(false);
        panelSetPackage.setVisible(true);
        panelSetPackage.setBackground(new Color(12,39,79));
         btnGeserKanan = new LoginPage.ButtonMelengkung(30,50,">",
                new Dimension(30,30));
         btnGeserKiri = new LoginPage.ButtonMelengkung(30,50,"<",
                new Dimension(30,30));
        btnGeserKanan.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                rotateLeft();
            }
        });
        btnGeserKiri.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                rotateRight();
            }
        });

        btnGeserKiri.setOpaque(false);
        btnGeserKanan.setOpaque(false);
        btnGeserKiri.setBackground(new Color(212,172,252));
        btnGeserKanan.setBackground(new Color(212,172,252));
        JLabel label = new JLabel("Select");
        label.setForeground(Color.white);
        label.setFont(new Font("Tahoma", Font.BOLD, 36));
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        panel.add(label);
        panelSetPackage.add(panel,new GridBagConstraints(2,0,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(0,0,0,0), 0, 0));
        panelSetPackage.add(carousels.get(0),new GridBagConstraints(0,1,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(50,0,0,0), 0, 0));
        panelSetPackage.add(btnGeserKiri, new GridBagConstraints(1,1,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(50,0,0,0), 0, 0));
        panelSetPackage.add(carousels.get(1),new GridBagConstraints(2,1,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(50,0,0,0), 0, 0) );
        panelSetPackage.add(carousels.get(2),new GridBagConstraints(4,1,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(50,0,0,0), 0, 0));
        panelSetPackage.add(btnGeserKanan, new GridBagConstraints(3,1,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(50,0,0,0), 0, 0));
        label = new JLabel(carousels.get(1).getName());
        label.setForeground(Color.white);
        label.setFont(new Font("Tahoma", Font.LAYOUT_LEFT_TO_RIGHT, 36));
        panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        panel.add(label);
        panelSetPackage.add(panel, new GridBagConstraints(2,2,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(30,0,0,0), 0, 0));
    }

    /*
    * Ketika carousel digeser maka tampilan harus diupdate.
    * method ini akan mengupdate posisi carousel dan label penjelas.*/
    public void updatePackage(){

        panelSetPackage.removeAll();
        JLabel label = new JLabel("Select");
        label.setForeground(Color.white);
        label.setFont(new Font("Tahoma", Font.BOLD, 36));
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        panel.add(label);
        panelSetPackage.add(panel,new GridBagConstraints(2,0,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(0,0,0,0), 0, 0));

        panelSetPackage.add(carousels.get(0),new GridBagConstraints(0,1,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(50,0,0,0), 0, 0));
        panelSetPackage.add(btnGeserKiri, new GridBagConstraints(1,1,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(50,0,0,0), 0, 0));
        panelSetPackage.add(carousels.get(1),new GridBagConstraints(2,1,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(50,0,0,0), 0, 0) );
        panelSetPackage.add(carousels.get(2),new GridBagConstraints(4,1,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(50,0,0,0), 0, 0));
        panelSetPackage.add(btnGeserKanan, new GridBagConstraints(3,1,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(50,0,0,0), 0, 0));
        label = new JLabel(carousels.get(1).getName());
        label.setForeground(Color.white);
        label.setFont(new Font("Tahoma", Font.LAYOUT_LEFT_TO_RIGHT, 36));
        panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        panel.add(label);
        panelSetPackage.add(panel, new GridBagConstraints(2,2,1,1,0,0,GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL, new Insets(30,0,0,0), 0, 0));
        panelSetPackage.revalidate();
        panelSetPackage.repaint();
    }

    void rotateLeft(){
        BiggerCarousel temp = carousels.get(0);
        for(int i = 0; i < carousels.size() - 1; i++){
            carousels.set(i, carousels.get(i+1));
        }
        carousels.set(carousels.size() - 1, temp);
        System.out.println(carousels.toString());
        updatePackage();
    }
    void rotateRight(){
        BiggerCarousel temp = carousels.get(carousels.size()-1);
        for (int i = carousels.size() - 1; i > 0; i--){
            carousels.set(i, carousels.get(i-1));
        }
        carousels.set(0,temp);
        updatePackage();
    };
}

/*
* Menu utama aplikasi. Menampilkan berbagai aktivitas yang dapat dilakukan member.
* Kelas ini berupa panel yang terbagi menjadi tiga bagian.
* Bagian atas berupa title, search bar, dan label tanggal. Bagian center berupa
* konten utama yaitu berbagai aktivitas yang dapat dilakukan. Bagian samping berupa side
* navigation bar*/

class MemberGUI extends  JPanel{
    Component parent;
    private  Member loginMember;
    JPanel topPanel, midPanel, bottomPanel;
    JPanel sidePanel;
    MemberGUI memberGUI;
    HashSet midPaneRealElements = new HashSet<>();
    JPanel panelNota;
    JLabel searchButton;
    boolean sidePanelActive = true;
    HashMap<String, Component> midComponent;

    MemberGUI(Component parent, Member member){

        this.parent = parent;
        this.loginMember = member;
        this.memberGUI = this;
        midComponent = new HashMap<>();
        setAllSize();
        this.setBackground(Color.pink);
        this.setLayout(new BorderLayout());
        createTopPanel();
        searchButton = new JLabel(new ImageIcon("search02.png"));
        createSidePanel();
        customizeTopPanel();
        createMidPanel();
        createPanelNota();
        customizeMidPanel();
    }

    public Member getLoginMember() {
        return loginMember;
    }

    // Halaman untuk menampilkan nota yang dimiliki member
    void createPanelNota() {
        panelNota = new JPanel(new BorderLayout());
        //panelNota.setPreferredSize(new Dimension(1680,1080));
        JPanel centerPanelOnTop = new JPanel();

        JPanel panelInformasi = new JPanel();
        panelInformasi.setPreferredSize(new Dimension(300,200));
        panelInformasi.setMinimumSize(new Dimension(300,200));
        panelInformasi.setSize(new Dimension(300,200));
        panelInformasi.setBackground(Color.white);
        panelInformasi.setVisible(true);
        JLabel labelInformasi = new JLabel("INFORMASI");
        labelInformasi.setFont(new Font("Serif", Font.PLAIN, 36));
        labelInformasi.setForeground(Color.white);
        panelInformasi.add(labelInformasi);
        panelNota.setOpaque(false);
        panelInformasi.setBackground(new Color(29,38,125));
        panelInformasi.setVisible(true);
        centerPanelOnTop.setOpaque(false);




        JPanel panelNotaData = new JPanel(new GridBagLayout());
        panelNotaData.setBackground(Color.black);
        panelNotaData.setOpaque(false);
        //panelNotaData.setPreferredSize(new Dimension(1366, 800));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        JScrollPane jScrollPanelNota = new JScrollPane(panelNotaData);
        jScrollPanelNota.setOpaque(false);

        LoginPage.ButtonMelengkung buttonMelengkung = new LoginPage.ButtonMelengkung(30,50,"Informasi");
        buttonMelengkung.setOpaque(false);
        buttonMelengkung.setBackground(new Color(212,172,252));
        JPanel panel = new JPanel();
        panel.setMaximumSize(new Dimension(500,300));
        centerPanelOnTop.setLayout(new BoxLayout(centerPanelOnTop, BoxLayout.Y_AXIS));
        centerPanelOnTop.add(jScrollPanelNota);
        centerPanelOnTop.setOpaque(false);

        //panelNota.add(buttonMelengkung, BorderLayout.NORTH);
        JFrame frameT = new JFrame();
        frameT.setSize(500,400);
        frameT.setContentPane(panelInformasi);
        frameT.setResizable(false);
        buttonMelengkung.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frameT.setVisible(true);
            }
        });

        jScrollPanelNota.getViewport().setOpaque(false);
        jScrollPanelNota.setBorder(null);
        jScrollPanelNota.getHorizontalScrollBar().setOpaque(false);
        jScrollPanelNota.getHorizontalScrollBar().setBorder(null);
        jScrollPanelNota.getHorizontalScrollBar().setBackground(new Color(212,172,252));
        jScrollPanelNota.getVerticalScrollBar().setBlockIncrement(128);
        jScrollPanelNota.getVerticalScrollBar().setUnitIncrement(16);
        jScrollPanelNota.getHorizontalScrollBar().setVisible(false);
        jScrollPanelNota.getVerticalScrollBar().setVisibleAmount(30);
       //  panelNotaData.setPreferredSize(midPanel.getPreferredSize());
       //jScrollPanelNota.setPreferredSize(midPanel.getPreferredSize());
       jScrollPanelNota.setMinimumSize(midPanel.getPreferredSize());
       // jScrollPanelNota.setMaximumSize(new Dimension(600,2000));
        jScrollPanelNota.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        panelNotaData.setOpaque(false);
       panelNotaData.setMinimumSize(new Dimension(1000,700));
      // panelNotaData.setOpaque(false);
        jScrollPanelNota.setAutoscrolls(true);
        jScrollPanelNota.getVerticalScrollBar().setOpaque(false);
        jScrollPanelNota.getVerticalScrollBar().setBackground(Color.black);
        jScrollPanelNota.setVisible(true);
        jScrollPanelNota.setPreferredSize(new Dimension(1680,580));
        jScrollPanelNota.getVerticalScrollBar().setUI(new BasicScrollBarUI(){
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(29,38,125);
                this.thumbHighlightColor = new Color(29,38,125);
                this.trackColor = new Color(0,0,0,0);
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                JButton button = super.createDecreaseButton(orientation);
                button.setBackground(new Color(29,38,125));
                return button;
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                JButton button = super.createIncreaseButton(orientation);
                button.setBackground(new Color(29,38,125));
                return button;
            }
        });
        jScrollPanelNota.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        ArrayList<NotaBuilder> notaBuilders = new ArrayList<>();
        gbc.gridx = 0;
        gbc.gridy = 0;

        for (int i = 0; i < loginMember.pointerNota; i++){
            gbc.gridx = i % 5;
            gbc.gridy = i / 5;
            notaBuilders.add(new NotaBuilder(loginMember.notaList[i],180,180,loginMember));
        }
        NotaBuilder.createNotaBuilder(notaBuilders, panelNotaData);
        frameT.setLocationRelativeTo(panelNota);
        panelNota.add(centerPanelOnTop,BorderLayout.CENTER);
        JLabel label = new JLabel("Your Nota List");
        label.setForeground(Color.white);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setFont(new Font("Serif", Font.LAYOUT_NO_LIMIT_CONTEXT,48));
        label.setBorder(new EmptyBorder(0,0,20,0));
        panel.add(label);
        panel.add(buttonMelengkung);
        panel.setOpaque(false);
        panelNota.add(panel, BorderLayout.NORTH);
        panelNota.setVisible(false);
        midComponent.put("panel nota", panelNota);
        midPanel.add(panelNota);


    }

    //Membuka halaman panel nota setelah button nota ditekan
    void openPanelNota(){
        Component panelNota = midComponent.get("panel nota");
        for (Component component : midPanel.getComponents()){
            if(! component.equals(panelNota))component.setVisible(false);
            else component.setVisible(true);
        }
        revalidate();
        repaint();
    }

    // Membuat side navigation bar
    void createSidePanel(){
        sidePanel = new JPanel();
        sidePanel.setBackground(new Color(0,84,127));
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setVisible(true);
        panel.setMinimumSize(new Dimension(40, 700));
        panel.setBackground(Color.black);
        panel.setOpaque(false);
        String[] funct = {"Home","Your Profile", "Setting","Log out"};
        MouseListener[] mouseListenerList= {
                new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        for(Component component :midComponent.values()) component.setVisible(false);
                        midComponent.get("panel utama").setVisible(true);
                        midPanel.revalidate();
                        midPanel.repaint();
                    }
                }, new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
            }
        }, new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
            }
        }, new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    MainFrame.getInstance().doMainMenu();
                } catch (BadLocationException ef){}
            }
        }
        };
        String[] images = {"icons8-home-96.png", "icons8-male-user-96.png","icons8-settings-100.png","icons8-logout-96.png"};
        for(int j = 0; j < 4; j++){
            JPanel innerPanel = new JPanel(new GridBagLayout());
            innerPanel.setPreferredSize(new Dimension(180,50));
            innerPanel.setMaximumSize(new Dimension(180, 50));
            innerPanel.setMinimumSize(new Dimension(180, 50));
            innerPanel.setBackground(new Color(0,84,127));
            JLabel label = new JLabel(funct[j]);
            label.setFont(new Font("Tahoma", Font.LAYOUT_LEFT_TO_RIGHT, 18));
            label.setHorizontalAlignment(SwingConstants.LEFT);
            label.setForeground(Color.white);
            Image image = new ImageIcon(images[j]).getImage();
            Image resizedImage = image.getScaledInstance(32,32,Image.SCALE_SMOOTH);
            JLabel labelIcon = new JLabel(new ImageIcon(resizedImage));
            innerPanel.add(labelIcon, new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.WEST,GridBagConstraints.NONE,
                    new Insets(0,0,0,0),0,0));
            innerPanel.add(label,  new GridBagConstraints(1,0,1,1,0,0,GridBagConstraints.WEST,GridBagConstraints.NONE,
                    new Insets(0,0,0,0),0,0));
            innerPanel.setVisible(true);
            innerPanel.addMouseListener(mouseListenerList[j]);

            innerPanel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    innerPanel.setBackground(new Color(57, 72, 103));
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    innerPanel.setBackground(new Color(0,84,127));
                }
            });
            panel.add(innerPanel, new GridBagConstraints(0,j, 1,1,0,0, GridBagConstraints.WEST, GridBagConstraints.VERTICAL,
                    new Insets(0,0,20,0), 0, 0));
        }
        LoginPage.ButtonMelengkung button = new LoginPage.ButtonMelengkung(50,30, ">", new Dimension(30,30));
        button.setOpaque(false);
        button.setBackground(new Color(58, 79, 122));
        button.addMouseListener(new MouseInputListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if(sidePanelActive) {
                    sidePanel.setPreferredSize(sidePanel.getMinimumSize());
                    for(Component component: panel.getComponents()){
                        System.out.println(component.getClass().getSimpleName());
                        if(component instanceof LoginPage.ButtonMelengkung){
                            System.out.println("catch");
                            continue;
                        }
                        component.setVisible(false);
                }
                    sidePanelActive = false;
                }
                else {

                    sidePanel.setPreferredSize(new Dimension(180,30));
                    for (Component component : panel.getComponents()){
                        component.setVisible(true);
                    }
                    sidePanelActive = true;
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }

            @Override
            public void mouseDragged(MouseEvent e) {

            }

            @Override
            public void mouseMoved(MouseEvent e) {

            }
        });
        panel.add(button,
                        new GridBagConstraints(0,4, 1,1,0,0, GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
                                new Insets(0,0,0,0), 0, 0));
        System.out.println("hore");
        sidePanel.add(panel);
        sidePanel.setVisible(true);
        this.add(sidePanel, BorderLayout.WEST);
    }
    void setAllSize(){
        this.setSize(1000,700);
        this.setPreferredSize(new Dimension(1000,700));
        this.setMaximumSize(new Dimension(1000,700));
    }


    // Atur tampilan center dari MemberGUI sebagai halaman utama aplikasi
    void createMidPanel(){
        this.midPanel = new JPanel();
        this.midPanel.setSize(new Dimension(parent.getWidth(), parent.getHeight() * 4 / 5));
        this.midPanel.setPreferredSize(new Dimension(parent.getWidth(), parent.getHeight() * 4 / 5));
        this.midPanel.setMinimumSize(new Dimension(parent.getWidth(), parent.getHeight() * 4 / 5));
        this.midPanel.setBackground(new Color(12,39,79));
        this.midPanel.setVisible(true);
        this.add(midPanel,BorderLayout.CENTER) ;
    }

    // kustomisasi tampilan center dari MemberGUI
    void customizeMidPanel(){
        this.midPanel.setLayout(new GridBagLayout());
        JPanel panelUtamaMid = new JPanel(new GridBagLayout());
        panelUtamaMid.setOpaque(false);
        panelUtamaMid.add(new CarouselPanel(),
                new GridBagConstraints(0,0,4,2,0,0,GridBagConstraints.NORTH,GridBagConstraints.VERTICAL,new Insets(0,0,0,0),0
                , 0 ));
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setMaximumSize(new Dimension(900, 90));
        panel.setPreferredSize(new Dimension(900, 90));
        panel.setOpaque(false);
        panelUtamaMid.add(new GreetingToUser(this.loginMember),new GridBagConstraints
                (2,4,2,1,0,0,
                        GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,new Insets(10,0,0,0),0
                , 0 ));
        panelUtamaMid.add(panel,  new GridBagConstraints(0,5,4,1,0,
                0,GridBagConstraints.CENTER,GridBagConstraints.NONE,new Insets(40,0,60,0),0
                , 0 ));
        panel.add(new IconPane(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        for (Component component : midComponent.values()){
                            component.setVisible(false);
                        }
                        LaundryOrderPanel laundryOrderPanel = new LaundryOrderPanel(memberGUI);
                        midPanel.add(laundryOrderPanel);
                        midComponent.put("laundry order panel", laundryOrderPanel);
                        midComponent.get("laundry order panel").setVisible(true);
                        midPanel.revalidate();
                        midPanel.repaint();

                    }
                }, new ImageIcon("order.png").getImage(), 48, 48, "Laundry Order"),
                LoginPage.createConstraint(0,2,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, 0, 0, 0,0,
                        new Insets(0,0,0,parent.getWidth()/11)));
        panel.add(new IconPane(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                openPanelNota();
            }
        },new ImageIcon("nota.png").getImage(), 48,48, "Your Invoices"),
                LoginPage.createConstraint(1,2,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, 0, 0, 0,0,
                        new Insets(0,0,0,parent.getWidth()/11)));
        panel.add(new IconPane(new ImageIcon("pricing.png").getImage(), 48,48, "Our Pricing"),
                LoginPage.createConstraint(2,2,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, 0, 0, 0,0,
                        new Insets(0,0,0,parent.getWidth()/11)));
        panel.add(new IconPane(new ImageIcon("contactus.png").getImage(), 48,48, " Contact Us"),
                LoginPage.createConstraint(3,2,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, 0, 0, 0,0,
                        new Insets(0,0,0,parent.getWidth()/11 )));
        this.midPanel.add(panelUtamaMid);
        midComponent.putIfAbsent("panel utama", panelUtamaMid);

    }


    // Ikon dengan tambahan fungsionalitas seperti dapat ditekan dan memiliki label
    static class IconPane extends JPanel{
        private JLabel label;
        private JLabel labelHeadLine;

        private int originalWidth;
        private int originalHeight;
        private int enlargerWidth;
        private int enlargerHeight;
        Image image ;
        int scaledX, scaledY;
        IconPane(MouseListener listener, Image image, int scaledX, int scaledY, String headline){
            this(image, scaledX, scaledY,headline);
            this.addMouseListener(listener);
        }


        IconPane(Image image, int scaledX, int scaledY, String headline){
            this.scaledX = scaledX;
            this.scaledY = scaledY;
            this.setLayout(new GridBagLayout());
            Image resizedImage =
                    image.getScaledInstance(scaledX,scaledY, Image.SCALE_SMOOTH);
            this.image = resizedImage;
            ImageIcon icon = new ImageIcon(resizedImage);
            this.setOpaque(false);this.setVisible(true);
            label = new JLabel(icon);
            this.add(label, LoginPage.createConstraint(0,0,GridBagConstraints.NORTH, GridBagConstraints.VERTICAL, 0, 0, 0,0,
                    new Insets(0,0,6,0)));
            labelHeadLine = new JLabel(headline);
            this.add(labelHeadLine, LoginPage.createConstraint(0,1,GridBagConstraints.NORTH, GridBagConstraints.VERTICAL, 0, 0, 0,0,
                    new Insets(0,0,6,0)));
            labelHeadLine.setFont(new Font("Tahoma", Font.BOLD, 16));
            labelHeadLine.setForeground(Color.white);
            this.originalHeight = this.getPreferredSize().height;
            this.originalWidth = this.getPreferredSize().width;
            this.enlargerHeight = (int) (originalHeight * 1.2);
            this.originalWidth= (int)  (originalWidth * 1.2);


            this.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {

                    Image imageRes = image.getScaledInstance(scaledX+1, scaledY+1, Image.SCALE_SMOOTH);
                    ImageIcon newIcon = new ImageIcon(imageRes);
                    label.setIcon(newIcon);
                    revalidate();
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    Image imageRes = image.getScaledInstance(scaledX,scaledY,Image.SCALE_SMOOTH);
                    label.setIcon(new ImageIcon(imageRes));

                    revalidate();
                    repaint();
                }
            });
        }
    }
    void createBottomPanel(){
        this.bottomPanel = new JPanel();
        this.bottomPanel.setSize(new Dimension(parent.getWidth(),
                parent.getHeight() - topPanel.getHeight() - midPanel.getHeight()));
        this.bottomPanel.setPreferredSize(new Dimension(parent.getWidth(), parent.getHeight() - topPanel.getHeight() - midPanel.getHeight()));
        this.bottomPanel.setMinimumSize(new Dimension(parent.getWidth(), parent.getHeight() - topPanel.getHeight() - midPanel.getHeight()));
        this.bottomPanel.setBackground(new Color(29,38,125));
        this.bottomPanel.setVisible(true);
        this.add(bottomPanel, BorderLayout.SOUTH) ;
    }
    void  createTopPanel(){
        // Buat header untuk MemberGUI

        this.topPanel = new JPanel();
        this.add(topPanel, BorderLayout.NORTH);
        this.topPanel.setSize(new Dimension(parent.getWidth(), parent.getHeight()/11));
        this.topPanel.setPreferredSize(new Dimension(parent.getWidth(), parent.getHeight()/11));
        this.topPanel.setMinimumSize(new Dimension(parent.getWidth(), parent.getHeight() / 11));
        this.topPanel.setBackground(new Color(29,38,125));
        this.topPanel.setVisible(true);
    }

    // Kustomisasi header untuk MemberGUI
    void customizeTopPanel(){
        LoginPage.RoundedTextField textField = new LoginPage.RoundedTextField(25,"Search");
        textField.setPreferredSize(new Dimension(60, 30));
        textField.setActionCommand("Search");
        JLabel jLabel = new JLabel("PacilWork");
        jLabel.setFont(new Font("Lucida Handwriting", Font.BOLD, 36));
        jLabel.setForeground(Color.white);
        LoginPage.ButtonMelengkung panelTanggal = new LoginPage.ButtonMelengkung(30,50,
                NotaManager.fmt.format(NotaManager.cal.getTime()));
        panelTanggal.setBackground(new Color(0,84,127));
        panelTanggal.setVisible(true);
        panelTanggal.setPreferredSize(new Dimension(160,30));
        panelTanggal.setOpaque(false);
        panelTanggal.getLabel().setForeground(Color.white);
        this.topPanel.setLayout(new GridBagLayout());
        this.topPanel.add(jLabel, new GridBagConstraints(0,0,1,1, 0, 0, GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(0,0,0,30), 0, 0));
        this.topPanel.add(searchButton, new GridBagConstraints(2,0,1,1, 0, 0, GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(0,0,0,30), 0, 0));
        this.topPanel.add(textField,new GridBagConstraints(1,0,1,1, 0, 0, GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(0,0,0,30), 0, 0));
        this.topPanel.add(panelTanggal,new GridBagConstraints(3,0,1,1, 0, 0, GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(0,0,0,10), 0, 0));


    }

}
// Menampilkan label-label yang berisi sapaan kepada member.
// Label-label ini dipadukan dalam satu panel agar lebih terorganisir
class GreetingToUser extends JPanel{
    JLabel labelGreet;
    JLabel askLabel;
    private Member member;
    GreetingToUser(Member member){
        this.member = member;
        this.setLayout(new GridBagLayout());
        this.labelGreet = new JLabel("Hello, "+this.member.getNama()+"!");
        this.labelGreet.setFont(new Font("Tahoma", Font.BOLD, 32));
        this.labelGreet.setForeground(Color.white);
        this.askLabel = new JLabel("What do you want to do right now?");
        this.askLabel.setForeground(Color.lightGray);
        this.askLabel.setFont(new Font
                ("Times New Roman", Font.CENTER_BASELINE, 20));
        this.add(labelGreet, new GridBagConstraints(
        0, 0, 1, 1, 0, 0, GridBagConstraints.WEST, GridBagConstraints.RELATIVE,
                new Insets(0,0,10, 0), 0, 0));
        this.add(askLabel, new GridBagConstraints(
                0, 1, 1, 1, 0, 0, GridBagConstraints.WEST, GridBagConstraints.RELATIVE,
                new Insets(0,0,10, 0), 0, 0));
        this.setOpaque(false);
        this.setVisible(true);
    }
}

//Menampilkan carousel yang tidak dapat ditekan dan berfungsi hanya sebagai penghias
class CarouselPanel extends JPanel{
    ArrayList<BiggerCarousel> allCarousels = new ArrayList<>();
    JLayeredPane layeredPane;

    CarouselPanel(String... imageString){
        for (String text : imageString){
            allCarousels.add(new BiggerCarousel("everything", new ImageIcon(text).getImage(),500,256));
        }
        this.setLayout(new GridBagLayout());
        layeredPane = new JLayeredPane();
        Timer timer = new Timer();
        createCarousel();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                geser();
                createCarousel();
                revalidate();
                repaint();
            }
        }, 7000, 7000);

        this.setOpaque(false);
        this.setVisible(true);
    }
    CarouselPanel(){
        allCarousels = new ArrayList<>();
        allCarousels.add(new BiggerCarousel("memberplus",new ImageIcon("memberPlus.png").getImage(), 500, 256));
        allCarousels.add(new BiggerCarousel("delivery",new ImageIcon("motor.png").getImage(), 500, 256));
        allCarousels.add(new BiggerCarousel("setrika",new ImageIcon("iron.png").getImage(), 500, 256));
        this.setLayout(new GridBagLayout());
        layeredPane = new JLayeredPane();
        Timer timer = new Timer();
        createCarousel();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                geser();
                createCarousel();
                revalidate();
                repaint();
            }
        }, 7000, 7000);

        this.setOpaque(false);
        this.setVisible(true);
    }
    void geser(){
        BiggerCarousel temp = allCarousels.get(0);
        for (int i = 0; i < allCarousels.size() - 1;i++){
            allCarousels.set(i, allCarousels.get(i+1));
        }
        allCarousels.set(allCarousels.size()-1, temp);
    }
    void createCarousel(){

        for(int i = 0; i < allCarousels.size(); i++){

            this.add(allCarousels.get(i), new GridBagConstraints((i)*4,0, 4, 1, 0,0 , GridBagConstraints.NORTH, GridBagConstraints.NONE,
                    new Insets(0,0,0,0), 0, 0));

        }
    }


}
//menampilkan carousel yang dapat ditekan
class BiggerCarousel extends JPanel{
    ImageIcon imageIcon;

    boolean aktif;
    private String name;
    BiggerCarousel(String name,Image image, int ukuranX, int ukuranY){
        Image resizedImage = image.getScaledInstance(ukuranX,ukuranY,Image.SCALE_SMOOTH);
        imageIcon = new ImageIcon(resizedImage);
        this.add(new JLabel(imageIcon));
        this.setVisible(true);
        this.setOpaque(false);
        this.name = name;
        this.setBackground(new Color(12,39,79));
    }
    BiggerCarousel(MouseListener mouseListener, String name, Image image, int ukuranX, int ukuranY){
        this(name, image, ukuranX, ukuranY);
        this.addMouseListener(mouseListener);
    }

    @Override
    public String getName() {
        return name;
    }
}

// Kelas untuk membuat halaman registrasi
class RegisterPanel extends JPanel{
    JPanel panelRegister;
    Column  firstNameColumn;
    Column lastNameColumn;
    Column telephoneColumn;
    Column emailColumn;
    Column passwordColumn, passwordSameColumn;
    Column alamatColumn;
    Component parent;

    LoginPage.ButtonMelengkung registerAsMember, registerAsEmployee;


    LoginPage.ButtonMelengkung buttonBack, buttonNext;
    RegisterPanel(Component parent){
        this.setBackground(new Color(12,39,79));
        this.setLayout(new GridBagLayout());
        this.parent = parent;
        panelRegister = new JPanel();
        panelRegister.setBackground(new Color(57,62,70));

        panelRegister.setOpaque(true);
        panelRegister.setSize(new Dimension(parent.getWidth()*3/4, 500));
        panelRegister.setMinimumSize(new Dimension(parent.getWidth()*3/4, 500));
        panelRegister.setPreferredSize(new Dimension(parent.getWidth()*3/4, 500));
        panelRegister.setVisible(true);
        this.add(panelRegister, LoginPage.createConstraint(0,0, GridBagConstraints.WEST, GridBagConstraints.NONE, 0, 0, 0, 0
        , new Insets(0,0,0,0)));
        this.setVisible(true);
        createColumn();
    }

    void createColumn (){

        panelRegister.setLayout(new GridBagLayout());
        JLabel label = new JLabel("Create New Account");
        label.setFont(new Font("Monospaced", Font.BOLD, 30));
        label.setForeground(new Color(212,172,252));
        GridBagConstraints gcb = LoginPage.createConstraint(0,0,GridBagConstraints.CENTER, GridBagConstraints.VERTICAL, 0, 0, 0,10
                ,new Insets(0,0,32,0));
        gcb.gridwidth = 3;
        panelRegister.add(label, gcb);
        Column columnLabelRegisterAs = new Column("Register As");
        panelRegister.add(columnLabelRegisterAs, LoginPage.createConstraint(0,1,GridBagConstraints.WEST, GridBagConstraints.VERTICAL, 0, 0, 0,0
                ,new Insets(0,0,20,10)));

        registerAsMember = new LoginPage.ButtonMelengkung(30,50,"Member");
        registerAsEmployee = new LoginPage.ButtonMelengkung(30, 50, "Employee");
        registerAsMember.setBackground(new Color(212,172,252));
        registerAsMember.addMouseListener(new MouseInputListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                registerAsMember.setBackground(new Color(212,172,252));
                registerAsEmployee.setBackground(Color.white);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }

            @Override
            public void mouseDragged(MouseEvent e) {

            }

            @Override
            public void mouseMoved(MouseEvent e) {

            }
        });
        registerAsEmployee.addMouseListener(new MouseInputListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                registerAsEmployee.setBackground(new Color(212,172,252));
                registerAsMember.setBackground(Color.white);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }

            @Override
            public void mouseDragged(MouseEvent e) {

            }

            @Override
            public void mouseMoved(MouseEvent e) {

            }
        });
        panelRegister.add(registerAsMember, LoginPage.createConstraint(1,1,GridBagConstraints.WEST, GridBagConstraints.VERTICAL, 0, 0, 0,0
                ,new Insets(0,0,20,10)));
        panelRegister.add(registerAsEmployee, LoginPage.createConstraint(2,1,GridBagConstraints.WEST, GridBagConstraints.VERTICAL, 0, 0, 0,0
                ,new Insets(0,0,20,10)));
        registerAsMember.setOpaque(false);
        registerAsEmployee.setOpaque(false);
        firstNameColumn = new Column(1,1, "First name *", 15, 30, false);
        panelRegister.add(firstNameColumn, LoginPage.createConstraint(0,2,GridBagConstraints.WEST, GridBagConstraints.VERTICAL, 0, 0, 0,0
                ,new Insets(0,0,0,10)));
        lastNameColumn = new Column(1,1, "Last name", 15, 30,false);
        panelRegister.add(lastNameColumn, LoginPage.createConstraint(1,2,GridBagConstraints.WEST, GridBagConstraints.VERTICAL, 0, 0, 0,0
                ,new Insets(0,0,0,10)));
        emailColumn = new Column(1,2, "Email address", 30, 30,false);
         gcb = LoginPage.createConstraint(2,2,GridBagConstraints.WEST, GridBagConstraints.VERTICAL, 0, 0, 0,0
                ,new Insets(0,0,0,10));
        gcb.gridwidth = 2;
        panelRegister.add(emailColumn, gcb);
        alamatColumn = new Column(1,3,"Home address",30,30,false);
        gcb = LoginPage.createConstraint(0,3,GridBagConstraints.WEST, GridBagConstraints.VERTICAL, 0, 0, 0,0
                ,new Insets(20,0,0,10));
        gcb.gridwidth = 2;
        panelRegister.add(alamatColumn, gcb);
        telephoneColumn = new Column(1,2,"Preferred contact number *", 30, 30,false);
        gcb = LoginPage.createConstraint(2,3,GridBagConstraints.WEST, GridBagConstraints.VERTICAL, 0, 0, 0,0
                ,new Insets(20,0,0,10));
        gcb.gridwidth = 2;
        panelRegister.add(telephoneColumn,gcb);
        passwordColumn = new Column(1,2,"Create your password *", 30, 30,true);
        gcb = LoginPage.createConstraint(0,4,GridBagConstraints.WEST, GridBagConstraints.VERTICAL, 0, 0, 0,0
                ,new Insets(20,0,50,10));
        gcb.gridwidth = 2;
        panelRegister.add(passwordColumn,gcb);
        passwordSameColumn = new Column(1,2,"Confirm your password *", 30, 30,true);
        gcb = LoginPage.createConstraint(2,4,GridBagConstraints.WEST, GridBagConstraints.VERTICAL, 0, 0, 0,0
                ,new Insets(20,0,50,10));
        gcb.gridwidth = 2;
        panelRegister.add(passwordSameColumn,gcb);
        buttonBack = new LoginPage.ButtonMelengkung(30, 50, "Back to Mainmenu", new Dimension(300, 30));
        gcb = LoginPage.createConstraint(0,5,GridBagConstraints.WEST, GridBagConstraints.VERTICAL, 0, 0, 0,0
                ,new Insets(20,0,30,10));
        gcb.gridwidth = 2;
        panelRegister.add(buttonBack,gcb);
        buttonBack.setVisible(true);
        buttonBack.setBackground(new Color(212,172,252));
        buttonBack.setOpaque(false);
        buttonNext = new LoginPage.ButtonMelengkung(30, 50, "Create Account", new Dimension(300, 30));
        gcb = LoginPage.createConstraint(2,5,GridBagConstraints.WEST, GridBagConstraints.VERTICAL, 0, 0, 0,0
                ,new Insets(20,0,30,10));
        gcb.gridwidth = 2;
        panelRegister.add(buttonNext,gcb);
        buttonNext.setVisible(true);
        buttonNext.setBackground(new Color(212,172,252));
        buttonNext.setOpaque(false);
        this.buttonNext.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                ValidatorRegister validator = new ValidatorRegister(firstNameColumn,lastNameColumn,telephoneColumn,
                        passwordColumn,passwordSameColumn, registerAsMember.getBackground().equals(new Color(212,172,252)));
                Member member = validator.register();
                if(member == null) return;
                member.setEmail(emailColumn.textField.getText());
                member.setHomeAddress(alamatColumn.textField.getText());
                if(member != null){
                    try {
                        MainFrame.getInstance().doMainMenu();
                        OptionPaneCustom.showAcceptedDialogRev("Success", "" +
                                "<html><div width=\"200px\">" +
                                "<p align=\"justify\";>Registration successfull. " +"Your ID is "+member.getId()+
                                ". Please login with the account.</p></div></html>");

                    }
                    catch (BadLocationException locationException){}
                    }
                }
               // OptionPaneCustom.showErrorDialogRev("Register Failed", "Member with this name and id is already exist");

        });
        lastNameColumn.setVisible(true);
        this.buttonBack.addMouseListener(new MouseInputListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    MainFrame mainFrame =  (MainFrame) parent;
                    mainFrame.doMainMenu();
                }
               catch (BadLocationException locationException){}
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {
                buttonBack.setBackground(new Color(212,172,252));
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                buttonBack.setBackground(new Color(250, 152, 132));
            }

            @Override
            public void mouseExited(MouseEvent e) {

            }

            @Override
            public void mouseDragged(MouseEvent e) {

            }

            @Override
            public void mouseMoved(MouseEvent e) {

            }
        });
     class SpecialLabel extends Column{
         SpecialLabel(String headline){
             super(headline);
         }
     }

    }
    static class Column extends JPanel{
        int rowSpan = 1;
        int columnSpan = 1;
        String headLine;

        JTextField textField;
        JLabel label;
        Column(int rowSpan, int columnSpan, String headLine, int size, int heightOfTextField, boolean isPassword){
            this.rowSpan = rowSpan;
            this.columnSpan = columnSpan;
            this.headLine = headLine;
            this.setLayout(new GridBagLayout());
            if(! isPassword )textField = new LoginPage.RoundedTextField(size);
            else textField = new LoginPage.RoundedPasswordTextField(size);
            textField.setPreferredSize(new Dimension(size, heightOfTextField));
            label = new JLabel(headLine);
           // this.setBackground(Color.red);
            label.setFont(new Font("Tahoma", Font.ROMAN_BASELINE, 13));
            label.setForeground(Color.white);
            this.setOpaque(false);
            this.add(label, LoginPage.createConstraint(0,0,GridBagConstraints.WEST, GridBagConstraints.VERTICAL, 0, 0, 0,0
            ,new Insets(0,0,0,0)));
            this.add(textField,LoginPage.createConstraint(0,1,GridBagConstraints.NORTH, GridBagConstraints.VERTICAL, 0, 0, 0,0
                    ,new Insets(10,0,0,0)) );
            this.setVisible(true);
        }
        Column(String headline){
            this.setLayout(new GridBagLayout());
            this.headLine = headline;
            label = new JLabel(headline);
            label.setForeground(Color.white);
            label.setFont(new Font("Tahoma", Font.ROMAN_BASELINE, 13));
            this.add(label);
            this.setMaximumSize(new Dimension(50, 25));
            this.setOpaque(false);
            this.setVisible(true);
        }
    }

}
public class Main {

}

// carousel untuk homepage yang berisi kata kata
class Carousel extends  JPanel implements MouseMotionListener, MouseInputListener {
    int indexing = 0;

    int offset = 0;
    int dragStart = 0;
    ArrayList<CarouselNode>  lista= new ArrayList<>();
    JLabel headLabel;

    JPanel jPanelMini;

    LoginPage.ButtonMelengkung panahKiri;
    LoginPage.ButtonMelengkung panahKanan;


    public void mouseClicked(MouseEvent e){}

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    public void mousePressed(MouseEvent e){}
    public void mouseReleased(MouseEvent e){
        if(offset < 0){
            updateRight();
        } else if (offset > 0) {
            updateLeft();
        }
        offset = 0;
    }
    Carousel(){
        lista.add(new CarouselNode("""
                Our company is a professional laundry service provider since 1998 
                that is ready to help you maintain the cleanliness and health of your clothes.
                We provide fast, efficient, and high-quality laundry services so that you can enjoy 
                the important moments in your life without having to worry about other things. In addition, 
                based on Maps rating, the locations under our supervision receive an average score of 98%.
                Very satisfying. We guarantee that you will not regret washing your clothes with us because we are the best in this field.
                """, "We are Reputable Laundry Company since 1998"));
        lista.add(new CarouselNode("""
                There are several laundry packages that we offer,
                namely Regular laundry, Fast laundry, and Express laundry.\s
                Regular laundry is the cheapest, priced at Rp 7000 per Kg,\s
                while Fast laundry costs Rp 10000 per Kg. Meanwhile,\s
                as the exclusive and fastest variant, Express laundry is\s
                priced at Rp 12000 per Kg. We are not only fast,
                but we are also fully responsible for our customer's\s
                clothes. We are even ready to give a refund in case of
                laundry service delays.
                """, "Get Your Laundry Done Your Way with Our Affordable and Reliable Packages"));
        lista.add(new CarouselNode("""
                We not only offer laundry services, but 
                also ironing and delivery services. For ironing 
                services, we charge 1000 per kg without any conditions.
                Meanwhile, our delivery service is priced starting from 2000
                for 4kg, and then an additional 500 per kg. We are always 
                committed to providing the best and high-quality laundry services for anyone.
                """, "Beyond Laundry: Complete Your Hassle-Free Experience with Our Ironing and Delivery Services"));
        this.setLayout(new GridBagLayout());


        panahKiri = new LoginPage.ButtonMelengkung(30,50, "<",new  Dimension(30,30));
        panahKanan = new LoginPage.ButtonMelengkung(50,50,">",new Dimension(30,30));
        headLabel = lista.get(indexing).headlineLabel;
        headLabel.setBorder(new EmptyBorder(20, 0, 0, 0));
        panahKanan.setBackground(new Color(212,172,252));
        panahKiri.setOpaque(false);
        panahKanan.setOpaque(false);
        panahKiri.setBackground(new Color(212,172,252));
        jPanelMini = new JPanel();
        jPanelMini.setSize(new Dimension(330, 220));
        jPanelMini.setMaximumSize(new Dimension(330, 220));
        jPanelMini.setPreferredSize(new Dimension(330,210));
        jPanelMini.add(headLabel);
        jPanelMini.setOpaque(false);
        panahKanan.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                indexing++;
                if (indexing >= lista.size()) indexing = 0;
                reFocus();
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        panahKiri.addMouseListener(new MouseInputListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                indexing--;
                if(indexing < 0) indexing = lista.size() -1;
                reFocus();
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }

            @Override
            public void mouseDragged(MouseEvent e) {

            }

            @Override
            public void mouseMoved(MouseEvent e) {

            }
        });
        addMouseMotionListener(this);
        addMouseListener(this);
        System.out.println(lista.get(indexing).getPreferredSize().width);
        reFocus();
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        int pergerakan = e.getX();
        this.offset += pergerakan - dragStart;
        dragStart = pergerakan;
    }

    private void reFocus(){
        //this.remove(headLabel);
        this.removeAll();
        //this.add(lista.get(indexing),LoginPage.createConstraint(1,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,
          //      0,0,0,0, new Insets(0,0,0,0)));
        this.add(lista.get(indexing), LoginPage.createConstraint(1,2,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,0,0,0,0,
                new Insets(0,0,0,0)));
        GridBagConstraints gbc = LoginPage.createConstraint(0,0,GridBagConstraints.CENTER,GridBagConstraints.HORIZONTAL,0,0,0,20,
                new Insets(0,0,0,10));
        gbc.gridwidth = 3;
        jPanelMini.removeAll();
        jPanelMini.add(lista.get(indexing).headlineLabel);
        jPanelMini.revalidate();
        jPanelMini.repaint();
        this.add(jPanelMini, gbc );
        //child.add(lista.get(indexing).headlineLabel, gbc);
        this.add(panahKiri, LoginPage.createConstraint(0,2,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,0,0,0,0,
                new Insets(0,0,30,10)));
        this.add(panahKanan, LoginPage.createConstraint(2,2,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,0,0,0,0,
                new Insets(0,10,30,0)));

        this.revalidate();
        this.repaint();
    }

    public void updateRight(){
        indexing++;
        if(indexing >= lista.size()) indexing = 0;
        reFocus();
    }
    public void updateLeft(){
        indexing--;
        if(indexing < 0) indexing = lista.size() -1;
        reFocus();
    }
    static class CarouselNode extends JPanel{
        JLabel label;
        JLabel headlineLabel;
        CarouselNode (String labelText, String headlineText)  {
            this.setOpaque(false);

            String text = "<html><div WIDTH=330><p align=\"justify\">" +"&rdquo;"+ labelText +"&rdquo;" +"</p></div></html>";
            label = new JLabel();
            label.setText(text);
            label.setFont(new Font("Monserrat", Font.ROMAN_BASELINE, 13));
            label.setForeground(Color.white);
            this.headlineLabel = new JLabel();
            this.headlineLabel.setText("<html><div WIDTH=330><p >"+headlineText+"</p></div></html>");
            headlineLabel.setFont(new Font("Tahoma", Font.BOLD, 28));
            this.headlineLabel.setForeground(Color.white);
           this.setLayout(new GridBagLayout());
            this.add(label,LoginPage.createConstraint(0,1,GridBagConstraints.NORTH, GridBagConstraints.VERTICAL, 0, 0,0 ,0,
                    new Insets(0,0,0,0)));
            this.setBorder(new EmptyBorder(0,0,50,0));

        }
    }

}



// Frame utama aplikasi ini

class MainFrame extends JFrame{
    LoginPage loginPage;
    RegisterPanel registerPanel;
    private static MainFrame mainFrame;

    static MainFrame getInstance() {
        if(mainFrame == null) mainFrame = new MainFrame();
        return mainFrame;
    }

    MemberGUI memberGUI;
    private MainFrame(){
        super();
        this.setSize(new Dimension(1000,700));
       // this.setPreferredSize(new Dimension(1000,700));
       //this.setMaximumSize(new Dimension(1200,800));
        this.setExtendedState(MAXIMIZED_BOTH);
        this.loginPage = new LoginPage(this);
        this.add(this.loginPage);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    public void doMemberGUI(Member member){
        if(loginPage != null)this.remove(loginPage);
        if(member instanceof Employee) memberGUI = new EmployeeGUI(this,(Employee) member);
        else memberGUI = new MemberGUI(this, member);
        setContentPane(memberGUI);
        invalidate();
        validate();
    }
    public void doRegister(){

        setContentPane(new RegisterPanel(this));
        invalidate();
        validate();

    }
    public void doMainMenu() throws BadLocationException{
        if(memberGUI != null) this.remove(memberGUI);
        setContentPane(this.loginPage = new LoginPage(this));
        invalidate();
        validate();
    }

    static class Animation extends  Thread{
        JPanel panel;
        float startOpacity;
        float endOpacity;
        long duration;
    public Animation(JPanel panel, float startOpacity,float endOpacity, long duration) {
        this.panel = panel;
        this.startOpacity = startOpacity;
        this.endOpacity = endOpacity;
        this.duration = duration;

    }

    public void run() {
        panel.setOpaque(true);
        panel.setBackground(new Color(
                panel.getBackground().getRed(),
                    panel.getBackground().getGreen(),
                    panel.getBackground().getBlue(),
                    (int) (255 * startOpacity)));
            long startTime = System.currentTimeMillis();
            while (System.currentTimeMillis() - startTime < duration) {
                long elapsedTime = System.currentTimeMillis() - startTime;
                float progress = (float) elapsedTime / (float) duration;
                float opacity = startOpacity + (endOpacity - startOpacity) * progress;
                panel.setBackground(new Color(
                        panel.getBackground().getRed(),
                        panel.getBackground().getGreen(),
                        panel.getBackground().getBlue(),
                        (int) (255 * opacity)));
                try {
                    Thread.sleep(10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            //panel.setVisible(false);
        }
    }}



// Kelas untuk menampilkan tampilan login page
class LoginPage extends JPanel{
    JPanel left;
    JPanel right;
    JPanel childOfRight;
    JPanel childOfRightMid, childChildOfRightMid;
    ButtonMelengkung loginButton;
    ButtonMelengkung registerButton;

    JLabel labelWelcome, labelTitle, labelUsername, labelPassword, labelLogin, dontHaveAnAccount;

    final String TEXT_WELCOME = "Welcome to";
    final String TITLE = "PacilWork";
    final String REGISTER = "Register";
    final String LOG_IN = "Log In";
    JPanel miniPanel;
    Component parent;



    RoundedTextField textField;
    RoundedPasswordTextField passwordField;
    LoginPage(Component parent) {
        super();
        this.setLayout(new GridBagLayout());
        this.setSize(parent.getSize());
        this.parent = parent;
        left = new JPanel();
        this.setBackground(new Color(12,39,79));
        left.setBackground(new Color(29,38,125)); // new Color(12,39,79)
        updateLeft();
        right = new JPanel();
        right.setBackground(new Color(12,39,79));
        updateRight();
        updateText();
        updateLeftPanel();
        this.add(left,setConstraint(0,0));
        this.add(right,setConstraint(1,0));
        this.setVisible(true);
        this.left.setVisible(true);
        this.right.setVisible(true);
        this.childOfRight.setVisible(true);
        this.childOfRightMid.setVisible(true);
    }

    void updateLeftPanel() {
        Carousel carousel = new Carousel();
        carousel.setOpaque(false);
        //carousel.setBackground(Color.BLACK);
        carousel.setSize(new Dimension(420,700));
        carousel.setMaximumSize(new Dimension(420,700));
        carousel.setPreferredSize(new Dimension(420, 700));
        carousel.setMinimumSize(new Dimension(420,700));
        left.setLayout(new GridBagLayout());
        left.add(carousel);
        carousel.setVisible(true);
    }
    void updateLeft(){
        this.left.setPreferredSize(new Dimension(this.getSize().width/9*4, this.getHeight()));
        this.left.setSize(new Dimension(this.getSize().width/3, this.getHeight()));
        this.left.setMaximumSize(new Dimension(this.getSize().width/9*4,this.getHeight()));
        this.left.setMinimumSize(new Dimension(this.getSize().width/9*4,this.getHeight()));
    }

    void updateText(){
        this.childOfRight = new JPanel(new GridBagLayout());
        this.childOfRightMid = new JPanel();
        this.childChildOfRightMid = new JPanel();
        childChildOfRightMid.setLayout(new GridBagLayout());
        childChildOfRightMid.setSize(new Dimension(380, 350));
        childChildOfRightMid.setPreferredSize(new Dimension(380, 350));
        childChildOfRightMid.setMaximumSize(new Dimension(380, 350));
       this.childOfRightMid.setOpaque(false);
       this.childOfRight.setOpaque(false);
       this.labelLogin = new JLabel("Log In");
       this.labelLogin.setFont(new Font("Monospaced", Font.BOLD, 28));
       this.labelLogin.setForeground(new Color(212,172,252));

        this.childOfRightMid.setLayout(new GridBagLayout());
        childChildOfRightMid.setBackground(new Color(57,62,70));
        this.childOfRightMid.add(childChildOfRightMid,createConstraint(0,0,GridBagConstraints.CENTER, GridBagConstraints.NONE, 0, 0, 0, 0, new Insets(0,0,20,0)));
        this.right.setLayout(new BorderLayout());
        textField = new RoundedTextField(32);
        passwordField = new RoundedPasswordTextField(32);
        this.labelWelcome = new JLabel(TEXT_WELCOME);
        this.labelWelcome.setFont(new Font("Lucida Handwriting", Font.ROMAN_BASELINE, 18));
        this.labelWelcome.setForeground(Color.white);
        this.labelTitle = new JLabel(TITLE);
        this.labelTitle.setFont(new Font("Lucida Handwriting", Font.BOLD, 56));
        this.labelTitle.setForeground(Color.white);
        this.labelUsername = new JLabel("ID");
        this.labelUsername.setForeground(new Color(212,172,252));
        this.labelUsername.setFont(new Font("Montserrat", Font.BOLD, 12));
        this.labelPassword = new JLabel("Password");
        this.labelPassword.setForeground(new Color(212,172,252));
        this.labelPassword.setFont(new Font("Montserrat", Font.BOLD, 12));
        this.childOfRight.add(labelWelcome, createConstraint(0,0, GridBagConstraints.EAST,
               GridBagConstraints.NONE,
                0,0,0,0, new Insets(16,0,0,0)));
        this.childOfRight.add(labelTitle, createConstraint(0,1,GridBagConstraints.NORTH, GridBagConstraints.NONE,0
                ,0,0,0, new Insets(0,0,0,0)));
        textField.setPreferredSize(new Dimension(0, 32));
        passwordField.setPreferredSize(new Dimension(0,32));
        this.childChildOfRightMid.add(labelLogin,createConstraint(0,0,GridBagConstraints.WEST,GridBagConstraints.NONE,0,0,0,0
                ,new Insets(0,0,48,0)));
        this.childChildOfRightMid.add(labelUsername,createConstraint(0,1,GridBagConstraints.WEST,GridBagConstraints.NONE,0,0,0,0
        ,new Insets(0,0,4,0)));
        this.childChildOfRightMid.add(textField, createConstraint(0,2,GridBagConstraints.NORTH,
                GridBagConstraints.NONE,0,0,0,0, new Insets(0,0,0,0)));
        this.childChildOfRightMid.add(labelPassword,createConstraint(0,3,GridBagConstraints.WEST,GridBagConstraints.NONE,0,0,0,0
                ,new Insets(15,0,4,0)));
        this.childChildOfRightMid.add(passwordField, createConstraint(0,4,GridBagConstraints.NORTH,
                GridBagConstraints.NONE,0,0,0,0, new Insets(0,0,25,0)));

        this.loginButton = new ButtonMelengkung(30,50, "Login");
        this.registerButton = new ButtonMelengkung(30,50, "Register");
        miniPanel = new JPanel(new GridBagLayout());
        dontHaveAnAccount = new JLabel("<html>Don't have an Account?<br>Register Now!</html>");
        dontHaveAnAccount.setForeground(Color.white);
        dontHaveAnAccount.setFont(new Font("Montserrat", Font.BOLD, 12));
        GridBagConstraints gcb = createConstraint(1, 0,GridBagConstraints.EAST, GridBagConstraints.NONE, 0, 0,0, 0,
                new Insets(0,0,4,0));
        gcb.gridwidth = 2;
        miniPanel.add(dontHaveAnAccount,gcb);
        miniPanel.add(loginButton,createConstraint(0, 1,GridBagConstraints.CENTER, GridBagConstraints.NONE, 0, 0,0, 0,
                new Insets(6,0,0,45)));
        miniPanel.add(registerButton,createConstraint(1, 1,GridBagConstraints.CENTER, GridBagConstraints.NONE, 0, 0,0, 0,
                new Insets(6,0,0,0)));
        miniPanel.setOpaque(false);
        this.childChildOfRightMid.add(miniPanel,createConstraint(0,5,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,0,0,0,0
        ,new Insets(0,0,10,0)));
        ButtonMelengkung buttonNextDay = new ButtonMelengkung(
                30,50,"Change day to next day");
        buttonNextDay.setOpaque(false);
        buttonNextDay.setBackground(new Color(212,172,252));
        buttonNextDay.setVisible(true);
        buttonNextDay.setPreferredSize(new Dimension(160,30));
        ButtonMelengkung panelTanggal = new ButtonMelengkung(30,50,
                NotaManager.fmt.format(NotaManager.cal.getTime()));
        panelTanggal.setBackground(new Color(29,38,125));
        panelTanggal.setVisible(true);
        panelTanggal.setPreferredSize(new Dimension(160,30));
        panelTanggal.setOpaque(false);
        panelTanggal.getLabel().setForeground(Color.white);
        buttonNextDay.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                NotaManager.toNextDay();
                panelTanggal.getLabel().setText(NotaManager.fmt.format(NotaManager.cal.getTime()));

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                buttonNextDay.setBackground(new Color(250, 152, 132));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                buttonNextDay.setBackground(new Color(212,172,252));
            }
        });



        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        panel.add(buttonNextDay, new GridBagConstraints(0,0, 1,1,0,0,GridBagConstraints.NORTH,GridBagConstraints.NONE,
                new Insets(0,0,20,0),0,0));
        panel.add(panelTanggal,new GridBagConstraints(0,1, 1,1,0,0,GridBagConstraints.NORTH,GridBagConstraints.NONE,
                new Insets(0,0,20,0),0,0));
        childOfRightMid.add(panel,createConstraint(0,1,GridBagConstraints.CENTER,
                GridBagConstraints.NONE, 0, 0, 0, 0,
                new Insets(0,0,70,0)));

        this.right.add(this.childOfRight,BorderLayout.NORTH);
        this.right.add(this.childOfRightMid, BorderLayout.CENTER);
        loginButton.setOpaque(false);
        loginButton.setBackground(new Color(212,172,252));
        loginButton.addMouseListener(new MouseInputListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                MainFrame frame = (MainFrame) parent;
                char[] pass = passwordField.getPassword();
                String passStr = String.valueOf(pass);
                ValidatorLogin validatorLogin = new ValidatorLogin(textField.getText(),passStr,
                        MainMenu.getInstance().getLoginManager().getSystem(textField.getText()));
                Member member = validatorLogin.requestLogin();
                if(member == null){
                    OptionPaneCustom.showErrorDialogRev("Login Failed",
                            "Login failed due to incorrect ID or password");
                    return;
                }
                frame.doMemberGUI(member);
                OptionPaneCustom.showAcceptedDialogRev("Login Succesfull",
                        "Login successful. Please do your laundry with us!");
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                loginButton.setBackground(new Color(250, 152, 132));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                loginButton.setBackground(new Color(212,172,252));
            }

            @Override
            public void mouseDragged(MouseEvent e) {

            }

            @Override
            public void mouseMoved(MouseEvent e) {

            }
        });
        registerButton.setBackground(new Color(212,172,252));
        registerButton.setOpaque(false);
        registerButton.addMouseListener(new MouseInputListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                MainFrame frame = (MainFrame) parent;
                frame.doRegister();
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                registerButton.setBackground(new Color(250, 152, 132));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                registerButton.setBackground(new Color(212,172,252));
            }

            @Override
            public void mouseDragged(MouseEvent e) {

            }

            @Override
            public void mouseMoved(MouseEvent e) {

            }
        });

    }
    static GridBagConstraints createConstraint(int x, int y, int anchor, int fill, int weightX, int weightY, int ipadX, int ipadY
    ,Insets insets){
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.weightx = weightX;
        gbc.weighty = weightY;
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.ipadx = ipadX;
        gbc.ipady = ipadY;
        gbc.anchor = anchor;
        gbc.fill = fill;
        gbc.insets = insets;
        return gbc;
    }

    void updateRight(){
        this.right.setPreferredSize(
                new Dimension(this.getSize().width - this.left.getPreferredSize().width,this.getHeight()));
        this.right.setSize(new Dimension(this.getSize().width - this.left.getPreferredSize().width
                ,this.getHeight()));
        this.right.setMaximumSize(new Dimension(this.getSize().width -
                this.left.getPreferredSize().width,this.getHeight()));
        this.right.setMinimumSize(new Dimension(this.getSize().width -
                this.left.getPreferredSize().width,this.getHeight()));
    }

    public static GridBagConstraints setConstraint(int x, int y){
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = x;
        gridBagConstraints.gridy = y;
        gridBagConstraints.ipadx = 0;
        gridBagConstraints.ipady = 0;
        gridBagConstraints.anchor = GridBagConstraints.WEST;
        gridBagConstraints.weightx = 0;
        gridBagConstraints.weighty = 0;
        gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
        return gridBagConstraints;
    }



    // kelas agar passwordfield lebih kekinian dengan rounded cornernya
    static  class RoundedPasswordTextField extends JPasswordField{
        private Shape shape;
        public RoundedPasswordTextField(int size){
            super(size);
            setOpaque(false);
        }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
            super.paintComponent(g2);
            g2.dispose();
        }

        @Override
        protected void paintBorder(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getForeground());
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
            g2.dispose();
        }

        @Override
        public boolean contains(int x, int y) {
            if (shape == null || !shape.getBounds().equals(getBounds())) {
                shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
            }
            return shape.contains(x, y);
        }

    }

    // kelas agar textfield lebih kekinian dengan rounded cornernya
   static class RoundedTextField extends JTextField {
        private Shape shape;
        private boolean isPrompt;
        private String prompt;

        public RoundedTextField(int size){
            super(size);
            setOpaque(false);
        }

        public RoundedTextField(int size, String prompt) {
            super(size);
            this.prompt = prompt;
            setOpaque(false);
            setForeground(Color.gray);
            isPrompt=true;
            addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    if(isPrompt){
                        isPrompt = false;
                        setText("");
                        setForeground(Color.black);
                        System.out.println('h');
                    }
                }

                @Override
                public void focusLost(FocusEvent e) {
                    if(getText().isEmpty()){
                        isPrompt = true;
                        setText(prompt);
                        setForeground(Color.gray);
                    }
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
            super.paintComponent(g2);
            g2.dispose();
        }

        @Override
        protected void paintBorder(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getForeground());
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
            g2.dispose();
        }

        @Override
        public boolean contains(int x, int y) {
            if (shape == null || !shape.getBounds().equals(getBounds())) {
                shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
            }
            return shape.contains(x, y);
        }
    }

    // Membuat rounded button yang lebih kekinian
    static class ButtonMelengkung extends JPanel {
        int widthToDraw, heightToDraw;
        JLabel label;

        public ButtonMelengkung(int widthToDraw,int heightToDraw, String text){
            super();
            setSize(new Dimension(78,30));
            setPreferredSize(new Dimension(78,30));
            setMinimumSize(new Dimension(78,30));
            setMaximumSize(new Dimension(78,30));
            this.widthToDraw = widthToDraw;
            this.heightToDraw = heightToDraw;
            this.label = new JLabel(text);
            this.label.setFont(new Font("Monserrat", Font.BOLD, 12));
            add(label);
        }

        public JLabel getLabel() {
            return label;
        }

        public ButtonMelengkung(int widthtoDraw, int heightToDraw, String text, Dimension dimension ){
            super();
            setSize(dimension);
            setPreferredSize(dimension);
            setMinimumSize(dimension);
            setMaximumSize(dimension);
            this.widthToDraw = widthToDraw;
            this.heightToDraw = heightToDraw;
            this.label = new JLabel(text);
            this.label.setFont(new Font("Monserrat", Font.BOLD, 12));
            add(label);
        }
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Dimension arcs = new Dimension(this.widthToDraw,this.heightToDraw);
            int width = getWidth();
            int height = getHeight();
            Graphics2D graphics = (Graphics2D) g;
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            //Draws the rounded opaque panel with borders.
            graphics.setColor(getBackground());
            graphics.fillRoundRect(0, 0, width-1, height-1, arcs.width, arcs.height);//paint background
            graphics.setColor(getForeground());
            graphics.drawRoundRect(0, 0, width-1, height-1, arcs.width, arcs.height);//paint border
        }
    }
}
import java.util.Arrays;

public class Member {

    // field
    protected String id;
    protected String password;
    protected String nama;
    protected Nota[] notaList = new Nota[2];

    protected int pointerNota =  0; // counter nota yang tersimpan di notaList member

    private String email = "";
    private String homeAddress = "";


    public void setEmail(String email) {
        this.email = email;
    }

    public void setHomeAddress(String homeAddress) {
        this.homeAddress = homeAddress;
    }

    public String getEmail() {
        return email;
    }

    public String getHomeAddress() {
        return homeAddress;
    }

    public Member(String nama, String id, String password, String email, String homeAddress ){
        this(nama, id, password);
        this.email = email;
        this.homeAddress = homeAddress;
    }
    public Member(String nama, String id, String password) {
        this.nama = nama;
        this.id = id;
        this.password = password;
    }

    /**
     * Method otentikasi member dengan ID dan password yang diberikan.
     *
     * @param id -> ID anggota yang akan diautentikasi.
     * @param password -> password anggota untuk mengautentikasi.
     * @return true jika ID dan password sesuai dengan instance member, false jika tidak.
     */
    public boolean login(String id, String password) {
        return id.equals(this.id) && authenticate(password);
    }

    /**
     * Menambahkan nota baru ke NotaList instance member.
     *
     * @param nota Nota object untuk ditambahkan.
     */
    public void addNota(Nota nota) {

        if(pointerNota == notaList.length){ // array doubling
            notaList = Arrays.copyOf(notaList, notaList.length * 2);
        }
        notaList[pointerNota++] = nota; // assign ke array dengan index pointerNota
        // kemudian increment pointerNota
    }

    /**
     * Method otentikasi member dengan password yang diberikan.
     *
     * @param password -> sandi password anggota untuk mengautentikasi.
     * @return true jika ID dan password sesuai dengan instance member, false jika tidak.
     */
    protected boolean authenticate(String password) {
        return this.password.equals(password); // return true jika password member sama
        // dengan password yang dimasukkan
    }

    // Dibawah ini adalah getter
    public String getNama() {
        return nama;
    }

    public String getId() {
        return id;
    }

    public Nota[] getNotaList() {
        return notaList;
    }
}
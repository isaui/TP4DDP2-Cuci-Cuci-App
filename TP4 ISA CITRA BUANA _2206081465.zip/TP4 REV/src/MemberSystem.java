import java.util.Arrays;

public class MemberSystem extends SystemCLI {
    /**
     * Memproses pilihan dari Member yang masuk ke sistem ini sesuai dengan menu specific.
     *
     * @param choice -> pilihan pengguna.
     * @return true jika user log.
     */
    @Override
    protected boolean processChoice(int choice) {
        boolean logout = false;
        if(choice == 1) buatNotaLaundry(); // branch untuk membuat nota
        else if(choice == 2) lihatDetailNota();// branch untuk melihat detail nota yang dimiliki user
        else if(choice == 3) logout = true; // branch untuk melakukan logout
        return logout;
    }

    // procedure method yang digunakan untuk membuat nota laundry dan kemudian
    // menyimpannya ke notaList yang terdapat di NotaManager.
    protected void buatNotaLaundry(){
        System.out.println("Masukan paket laundry:");
        tampilkanPaket();
        String paketDipilih = validasiPaket();
        int berat = validasiBerat();
        Nota notaBaru = new Nota(this.loginMember,berat,paketDipilih,
                NotaManager.fmt.format(NotaManager.cal.getTime()));
        tawarkanJasaSetrika();
        String terima = in.nextLine();
        if(! (terima.equalsIgnoreCase("x"))) notaBaru.addService(new SetrikaService());
        tawarkanJasaPengantaran();
        terima = in.nextLine();
        if(!(terima.equalsIgnoreCase("x"))) notaBaru.addService(new AntarService());
        System.out.println("Nota berhasil dibuat!");
        NotaManager.addNota(notaBaru);
        this.loginMember.addNota(notaBaru);
    }

    /*
     * method yang digunakan untuk mengiterasi dan
     * melakukan print terhadap nota yang tersimpan di
     * notaList member yang login atau member ini*/
    protected void lihatDetailNota(){
        for (int i = 0; i < loginMember.getNotaList().length; i++){
            if(loginMember.getNotaList()[i] != null){
                System.out.println(loginMember.getNotaList()[i]);
            }
        }
    }

    /*
     * method yang melakukan print informasi
     * dan penawaran jasa setrika*/
    protected void tawarkanJasaSetrika(){
        System.out.println("Apakah kamu ingin cucianmu disetrika oleh staff professional kami?");
        System.out.println("Hanya tambah 1000 / kg :0");
        System.out.print("[Ketik x untuk tidak mau]: ");
    }

    /*
     * method yang melakukan print informasi dan
     * penawaran jasa pengantaran*/
    protected void tawarkanJasaPengantaran(){
        System.out.println("Mau diantar oleh kurir kami? Dijamin aman dan cepat sampai tujuan!");
        System.out.println("Cuma 2000 / 4kg, kemudian 500 / kg");
        System.out.print("[Ketik x untuk tidak mau]: ");
    }

    /*
     * method yang berguna untuk memvalidasi berat dan
     * me-return berat yang sudah sesuai dengan ketentuan.
     * */
    private int validasiBerat(){
        int berat;
        System.out.println("Masukkan berat cucian Anda [Kg]:");
        while (true){ // Looping untuk validasi berat cucian
            String beratInString = in.nextLine();
            if(beratInString.chars().allMatch(Character::isDigit)){
                // Berat yang diinput oleh user  pada #beratInString sudah berupa digit
                berat = Integer.parseInt(beratInString);
                // Parsing string #beratInString ke integer
                if(berat > 0){
                    // Berat pada #berat sudah valid
                    if (berat < 2){
                        // Jika berat dibawah 2 Kg maka dianggap 2 Kg
                        berat = 2;
                        System.out.println("Cucian kurang dari 2 kg, maka cucian akan dianggap sebagai 2 kg");
                    }
                    break; // Keluar dari loop
                }
            }
            // #BeratInString tidak valid karena mengandung karakter non-digit
            System.out.println("Harap masukkan berat cucian Anda dalam bentuk bilangan positif");
        }
        return berat;
    }

    /*
     * method yang digunakan untuk memvalidasi jenis
     * paket yang dipilih sehingga sesuai dengan ketentuan*/
    private String validasiPaket(){
        String paket;
        while (true) { // Looping untuk validasi nama paket
            paket = in.nextLine();
            if(paket.equalsIgnoreCase("reguler") || paket.equalsIgnoreCase("fast") ||
                    paket.equalsIgnoreCase("express")){
                // Paket tersedia
                break; // Input sudah benar sehingga keluar dari loop
            } else if (paket.equals("?")) {
                //Branch untuk "?" dengan kata lain untuk bertanya
                tampilkanPaket();
                System.out.println("Masukkan paket laundry:");
            } else {
                // Paket tidak ada
                System.out.println("Paket "+paket+" tidak diketahui");
                System.out.println("[Ketik ? untuk mencari tahu jenis paket]");
            }
        }
        return paket;
    }

    // procedure method untuk menampilkan jenis paket
    private void tampilkanPaket() {
        System.out.println("+-------------Paket-------------+");
        System.out.println("| Express | 1 Hari | 12000 / Kg |");
        System.out.println("| Fast    | 2 Hari | 10000 / Kg |");
        System.out.println("| Reguler | 3 Hari |  7000 / Kg |");
        System.out.println("+-------------------------------+");
    }

    /**
     * Displays specific menu untuk Member biasa.
     */

    // display specific menu
    @Override
    protected void displaySpecificMenu() {
        System.out.println("1. Saya ingin laundry");
        System.out.println("2. Lihat detail nota saya");
        System.out.println("3. Logout");
    }

    /**
     * Menambahkan Member baru ke sistem.
     *
     * @param member -> Member baru yang akan ditambahkan.
     */

    /*
     * Method untuk menambahkan member ke member
     * list, tetapi sebelum itu perlu dicek apakah array memberList
     * sudah penuh atau belum. Jika sudah, maka harus dilakukan array doubling
     * */
    public void addMember(Member member) {
        // TODO
        if(memberPointer == memberList.length)
            memberList = Arrays.copyOf(memberList, memberList.length * 2);
        memberList[memberPointer++] = member;
    }
}

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

public class Nota {


    //field
    private Member member; // composition.
    // reference ke objek Member mana yang menjadi pemilik Nota ini
    private String paket; // nama paket
    private LaundryService[] services; // array untuk menyimpan service
    private long baseHarga; // harga satuan paket * berat sebelum terkena penalti harga
    private int sisaHariPengerjaan; // simpan hari sisa pengerjaan sesuai jenis paket yang dipilih
    private  int berat;// simpan berat
    private int id; // simpan id unik
    private String tanggalMasuk; // simpan tanggal masuknya suatu paket
    private boolean isDone; // boolean untuk menyatakan apakah seluruh service yang ada
    // di services sudah selesai dikerjakan
    static public int totalNota = 0; // static counter yang nantinya nilainya digunakan untuk men-assign id.
    private int selisihTanggal; // sama seperti sisa hari pengerjaan, tetapi nilainya fixed.
    // Digunakan untuk menghitung selisih tanggal masuk dan tanggal seharusnya keluar suatu paket.
    private int hargaSatuanPaket; // harga satuan bergantung terhadap jenis paket yang dipilih

    private int servicesPointer = 0; // pointer untuk jumlah services yang diambil oleh user

    private int servicesHasBeenDonePointer = 0; // pointer untuk mengetahui sudah sampai
    // mana services yang telah selesai dikerjakan
    private long kompensasiHarga; // hitung penalti harga

    public int getServicesHasBeenDonePointer() {
        return servicesHasBeenDonePointer;
    }


    public Nota(Member member, int berat, String paket, String tanggal) {
        //assign and calculate all field
        this.member = member;
        this.berat = berat;
        this.paket = paket;
        this.tanggalMasuk = tanggal;
        this.id = totalNota++;
        this.services = new LaundryService[2];
        this.sisaHariPengerjaan = this.selisihTanggal = aturSisaHariPengerjaan();
        aturHargaSatuanPaket();
        aturBaseHarga();
        addService(new CuciService());
    }

    public Member getMember() {
        return member;
    }

    /*
     * procedure method untuk mengatur field base harga sebesar nilai
     * hargaSatuanPaket dikali berat*/
    private void aturBaseHarga(){
        this.baseHarga = this.hargaSatuanPaket * berat;
    }

    /*
     * method untuk melakukan return sisa hari pengerjaan yang sesuai
     * dengan nama (jenis) paket yang dipilih*/
    private int aturSisaHariPengerjaan(){
        return this.paket.equalsIgnoreCase("Reguler")?
                3:this.paket.equalsIgnoreCase("Fast")?2:1;
    }
    /*
     * procedure method untuk mengatur field haragSatuanPaket sesuai dengan
     *  nama (jenis) paket yang dipilih*/
    private void aturHargaSatuanPaket(){
        this.hargaSatuanPaket = this.paket.equalsIgnoreCase("Express")? 12000 :
                this.paket.equalsIgnoreCase("Fast")? 10000 : 7000;
    }

    /*method untuk menambahkan service yang dipilih ke nota.
     * karena menggunakan array maka perlu dilakukan doubling jika pointerServices
     * telah menyamai panjang dari array services*/
    public void addService(LaundryService service){
        //TODO
        if(this.servicesPointer == this.services.length){
            this.services = Arrays.copyOf(this.services, this.services.length * 2);
        }
        this.services[this.servicesPointer++] = service;
    }

    /* kerjakan service yang tersimpan di array services.
     * Apabila pointer servicehasBeenDonePointer telah sama atau lebih dari pointer servicesPointer
     * maka tandanya nota telah selesai dikerjakan sehingga dilakukan setDone(true).
     * Method ini mereturn status nota saat ini
     * */
    public String kerjakan(){
        if(this.servicesHasBeenDonePointer < this.servicesPointer){
            if(servicesHasBeenDonePointer == servicesPointer -1) setDone(true);
            return "Nota " +id+" : "+ this.services[this.servicesHasBeenDonePointer++].doWork();
        }
        setDone(true);
        return getNotaStatus();
    }


    /*
     * Apabila nota belum selesai, maka decrement sisaHariPengerjaan.
     * Apabila sisaHariPengerjaan < 0 maka artinya telat sehingga
     * kompensasiHarga harus ditambah sebanyak 2000 atau dengan
     *  kata lain terjadi penalti harga*/
    public void toNextDay() {
        // TODO
        if(isDone()) return;
        this.sisaHariPengerjaan--;
        if(this.sisaHariPengerjaan < 0) this.kompensasiHarga += 2000;
    }

    // setter field isDone
    public void setDone(boolean done) {
        this.isDone = done;
    }


    // getter field baseHarga
    public long getBaseHarga() {
        return this.baseHarga;
    }

    // harga akhir = base harga (sudah dikalikan berat) + harga service tambahan - kompensasi harga
    public long calculateHarga(){

        long harga = getBaseHarga();
        for(int i = 0; i < servicesPointer;i++) harga+= services[i].getHarga(this.berat);
        return harga - kompensasiHarga < 0? 0 : harga - kompensasiHarga;
    }

    // Jika nota telah selesai maka return "Sudah selesai." .
    // Jika belum selesai maka return "Belum selesai."
    public String getNotaStatus(){
        if(isDone()) return  "Nota "+ id +" : Sudah selesai.";
        return "Nota "+id+" : Belum selesai.";
    }

    public int getSelisihTanggal() {
        return selisihTanggal;
    }

    public String getTanggalMasuk() {
        return tanggalMasuk;
    }

    // getter field id
    public int getId() {
        return id;
    }

    // getter hargaSatuanPaket
    public int getHargaSatuanPaket() {
        return hargaSatuanPaket;
    }

    // toString untuk merepresentasikan informasi nota dalam String
    @Override
    public String toString(){
        // TODO
        String[] tanggalMasukArray = this.tanggalMasuk.split("/");
        LocalDate tanggalTerima = LocalDate.of(Integer.valueOf(tanggalMasukArray[2]),
                Integer.valueOf(tanggalMasukArray[1]), Integer.valueOf(tanggalMasukArray[0]));
        LocalDate tanggalKeluar = tanggalTerima.plusDays(this.selisihTanggal);
        StringBuilder serviceApaSaja = new StringBuilder();
        for (int i = 0; i < servicesPointer; i++)
            serviceApaSaja.append("-"+services[i].getServiceName()+" @ Rp."+
                    services[i].getHarga(berat)+"\n");
        String kompensasi = this.sisaHariPengerjaan < 0 || kompensasiHarga > 0?
                String.format("Ada kompensasi keterlambatan %d * 2000 hari", Math.abs(sisaHariPengerjaan))
                : "";
        return kompensasi.isEmpty()? String.format("""
                [ID Nota = %d]
                ID    :\s%s
                Paket :\s%s
                Harga :\n%d kg x %d = %d
                tanggal terima  :\s%s
                tanggal selesai :\s%s
                --- SERVICE LIST ---
                %s
                Harga Akhir: %d
                """, getId(), member.getId(),getPaket()
                ,getBerat(),getHargaSatuanPaket(),getBaseHarga(), tanggalTerima.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                ,tanggalKeluar.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),serviceApaSaja.toString().trim()
                ,calculateHarga()) : String.format("""
                [ID Nota = %d]
                ID    :\s%s
                Paket :\s%s
                Harga :\n%d kg x %d = %d
                tanggal terima  :\s%s
                tanggal selesai :\s%s
                --- SERVICE LIST ---
                %s
                Harga Akhir: %d\s%s
                """, getId(), member.getId(),getPaket(),getBerat(),getHargaSatuanPaket(),getBaseHarga(), tanggalTerima.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                ,tanggalKeluar.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),serviceApaSaja.toString().trim()
                ,calculateHarga(),kompensasi);
    }


    // getter untuk field paket
    public String getPaket() {
        return paket;
    }

    // getter untuk field berat
    public int getBerat() {
        return berat;
    }

    // getter untuk field tanggalMasuk
    public String getTanggal() {
        return tanggalMasuk;
    }

    // getter untuk field sisaHariPengerjaan
    public int getSisaHariPengerjaan(){
        return sisaHariPengerjaan;
    }

    // getter untuk field isDone
    public boolean isDone() {
        return isDone;
    }

    // getter untuk field services
    public LaundryService[] getServices(){
        return services;
    }
}


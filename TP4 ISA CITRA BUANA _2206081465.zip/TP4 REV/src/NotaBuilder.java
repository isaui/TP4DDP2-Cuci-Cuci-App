import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Collection;


/*
* Kelas yang digunakan untuk melambangkan ikon nota apakah nota tersebut bagian dari nota
* express, fast ataupun reguler. Apabila ditekan maka akan menampilkan
* informasi tentang nota yang terkait*/
public class NotaBuilder extends JPanel {
    protected Nota nota;
    protected   Member member;
    protected   JLabel imageContent, descriptionLabel;

    protected final String EXPRESS = "expressnota.png", FAST="fastnota.png",REGULER="regulernota.png";
    protected String imageStr;


    public NotaBuilder(Nota nota, int x, int y, Member member){
        this.nota = nota;
        System.out.println(nota.getPaket());
        imageStr =  nota.getPaket().split(" ")[0].equalsIgnoreCase("Reguler")? REGULER :
                nota.getPaket().split(" ")[0].equalsIgnoreCase("Fast")? FAST : EXPRESS;
        Image image = new ImageIcon(imageStr).getImage();
        this.setLayout(new GridBagLayout());
        Image resizedImage = image.getScaledInstance(x,y,Image.SCALE_SMOOTH);
        this.imageContent = new JLabel(new ImageIcon(resizedImage));
        this.descriptionLabel = new JLabel("<html><p align=\"justify\"; width=\"180\">" +
                "Dipesan oleh %s pada %s (%s) </p></html>".formatted(member.getNama(),nota.getTanggalMasuk(),
                        nota.isDone()?"Sudah selesai" : "Belum selesai"));
        this.descriptionLabel.setFont(new Font("Serif", Font.ROMAN_BASELINE, 16));
        this.descriptionLabel.setForeground(Color.white);
        this.descriptionLabel.setHorizontalAlignment(SwingConstants.CENTER);
        this.add(imageContent, new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.CENTER,GridBagConstraints.NONE,
                new Insets(0,0,0,0), 0,0));
        this.add(descriptionLabel, new GridBagConstraints(0,1,1,1,0,0,GridBagConstraints.CENTER,GridBagConstraints.NONE,
                new Insets(0,0,0,0), 0,0));
        this.setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, Color.PINK));
        this.setVisible(true);
        this.setOpaque(false);
    }
    public NotaBuilder(Image image, int x, int y){
        this.setLayout(new GridBagLayout());
        Image resizedImage = image.getScaledInstance(x,y,Image.SCALE_SMOOTH);
        this.imageContent = new JLabel(new ImageIcon(resizedImage));
        this.descriptionLabel = new JLabel("<html><p align=\"justify\"; width=\"200\">" +
                "Dipesan oleh Nama Anda pada tanggal sekian</p></html>");
        this.descriptionLabel.setFont(new Font("Serif", Font.ROMAN_BASELINE, 16));
        this.descriptionLabel.setForeground(Color.white);
        this.descriptionLabel.setHorizontalAlignment(SwingConstants.CENTER);
        this.add(imageContent, new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.CENTER,GridBagConstraints.NONE,
                new Insets(0,0,0,0), 0,0));
        this.add(descriptionLabel, new GridBagConstraints(0,1,1,1,0,0,GridBagConstraints.CENTER,GridBagConstraints.NONE,
                new Insets(0,0,0,0), 0,0));
        this.setVisible(true);
        this.setOpaque(false);
    }
    static void createNotaBuilder(Collection<NotaBuilder> collection, JPanel parent){
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15,15,15,15);
        gbc.gridwidth = 1;
        int i = 0;

        int akhir = collection.size();
        for (NotaBuilder ele : collection){
            gbc.gridx = i%4;
            gbc.gridy = i/4;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.NORTH;
            gbc.fill = GridBagConstraints.VERTICAL;
            ele.setPreferredSize(new Dimension(200,300));
            ele.setMinimumSize(new Dimension(200,300));
            ele.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    new NotaGUI(ele.nota,"pacilwork.png" , 100,100);

                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    //ele.imageContent.setIcon(new ImageIcon(new ImageIcon("")));
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    super.mouseExited(e);
                }
            });
            parent.add(ele,gbc);
            i++;
        }
        if(parent.getComponents().length == 0){
            JLabel label = new JLabel("-- Still Empty --");
            label.setForeground(Color.white);
            label.setFont(new Font("Segoe UI", Font.ROMAN_BASELINE,36));
            parent.add(label, new GridBagConstraints(5,0,1,1,0,0,GridBagConstraints.NORTH,GridBagConstraints.NONE,new Insets(100,0,0,158)
            , 0,0));
        }
        for(int j = 0; i < 6;i++ ){
            JPanel panel = new JPanel();
            panel.setOpaque(false);
            panel.setSize(new Dimension(40,40));
            panel.setPreferredSize(new Dimension(40,40));
            panel.setPreferredSize(new Dimension());
            GridBagConstraints gridBag = new GridBagConstraints();
            gridBag.gridx = 0;
            gridBag.gridwidth = 4;
            gridBag.gridy = i+j;
          //  gridBag.anchor = GridBagConstraints.NORTH;
            gridBag.insets = new Insets(50,10,0,10);
            parent.add(panel,gridBag);
        }


    }

}

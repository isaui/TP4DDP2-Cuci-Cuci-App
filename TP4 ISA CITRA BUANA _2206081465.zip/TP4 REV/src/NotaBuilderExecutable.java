import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


/*
* Kelas yang berupa panel yang menampilkan nota dan apabila buttonnya diklik
* maka nota yang tersimpan atau terkait dengannya akan dikerjakan.
* Sub Class dari NotaBuilder karena kelas NotaBuilderExecutable
* adalah NotaBuilder yang diberi kemampuan untuk dikerjakan*/
public class NotaBuilderExecutable extends  NotaBuilder {
    private LoginPage.ButtonMelengkung doWorkButton;
    private Component parent;
    public NotaBuilderExecutable(Nota nota, int x, int y, Member member, Component parent){
        super(nota, x, y, member);
        this.parent = parent;
        this.doWorkButton = new LoginPage.ButtonMelengkung(30,50, "Mulai "+
                nota.getServices()[nota.getServicesHasBeenDonePointer()].getServiceName());
        this.doWorkButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                new NotificationPopUp(nota.kerjakan());
                setVisible(false);
                EmployeeGUI employeeGUI = ((EmployeeGUI) parent);
                employeeGUI.labelNotif.setText(employeeGUI.notif());
              //  ((EmployeeGUI) parent).midPanel.remove(panel);
               // ((EmployeeGUI) parent).customizeMidPanel();
              //  ((EmployeeGUI) parent).midPanel.revalidate();
              //  ((EmployeeGUI) parent).midPanel.repaint();
                revalidate();
                repaint();
            }
        });
        this.add(doWorkButton, new GridBagConstraints(0,2,1,1,0,0,GridBagConstraints.CENTER,GridBagConstraints.NONE,
                new Insets(10,0,0,0), 0,0));
       this.doWorkButton.setOpaque(false);
       this.doWorkButton.setBackground(new Color(212,172,252));
       this.doWorkButton.setPreferredSize(new Dimension(120,30));
       this.setPreferredSize(new Dimension(200,300));
       this.setMinimumSize(new Dimension(200,300));
    }
}

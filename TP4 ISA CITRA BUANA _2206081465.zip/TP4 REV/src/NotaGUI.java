import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class NotaGUI extends JFrame{
    private JPanel panel;
    private JLabel companyTitle, companyImage;
    private final  String COMPANY_NAME = "Pacilworks";
    private final String ADDRESS = "Kecamatan Address Kota Address 08XXX";
    private JLabel address;
    private JLabel packageName;
    private  JLabel idLabel;
    Nota nota;
    private JLabel tanggalMasukLabel;
    private JLabel borderTop;
    private JLabel servicesLabel;

    private JLabel packageAnswerName;
    private JLabel serviceListPanel;
    ArrayList<Component> components = new ArrayList<>();

    public NotaGUI(Nota nota, String imageStr, int x, int y){
        this.setSize(new Dimension(500,700));
        this.setResizable(false);
        panel = new JPanel(new GridBagLayout());
        panel.setPreferredSize(this.getSize());
        this.setContentPane(panel);
        this.companyTitle = createLabel(COMPANY_NAME, new Font("Times New Roman", Font.PLAIN, 22),
                Color.black);
        this.companyImage = createLabelImage(imageStr,x,y);
        this.nota = nota;
        this.address = createLabel(ADDRESS, new Font("Times New Roman", Font.TRUETYPE_FONT,
               16), Color.gray);
        this.tanggalMasukLabel = createLabel(nota.getTanggal(),new Font("Times New Roman", Font.TRUETYPE_FONT,
               16), Color.gray );
        this.borderTop = createLabel("• • • • • • • • • • • • • • • • • • • • • • •", new
                Font("Montserrat", Font.TRUETYPE_FONT, 22), new Color(172, 188, 255));
        this.packageName = createLabel("Package : ",new Font("Times New Roman", Font.TRUETYPE_FONT,
                16), Color.BLACK );

        this.packageAnswerName = createLabel(nota.getPaket(),new Font("Times New Roman",
                Font.TRUETYPE_FONT,16), Color.black);
        this.setTitle("Receipt");
        this.setVisible(true);
        this.idLabel =createLabel("Package ID : ",new Font("Times New Roman", Font.TRUETYPE_FONT,
                16), Color.BLACK );
        LoginPage.ButtonMelengkung buttonMelengkung = new LoginPage.ButtonMelengkung(30,50, "Oke");
        buttonMelengkung.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose();
            }
        });
        buttonMelengkung.setOpaque(false);
        buttonMelengkung.setBackground(new Color(212,172,252));
        serviceListPanel  = createLabel("• • • • • • •SERVICE LIST • • • • • • "
                ,new Font("Montserrat", Font.TRUETYPE_FONT,
                22), new Color(172, 188, 255));
        servicesLabel = createLabel(extractService(nota.getServices()),new Font("Times New Roman", Font.TRUETYPE_FONT,
                16), Color.BLACK);
        String[] tanggalMasukArray = nota.getTanggalMasuk().split("/");
        LocalDate tanggalTerima = LocalDate.of(Integer.valueOf(tanggalMasukArray[2]),
                Integer.valueOf(tanggalMasukArray[1]), Integer.valueOf(tanggalMasukArray[0]));
        LocalDate tanggalKeluar = tanggalTerima.plusDays(nota.getSelisihTanggal());
        components.addAll(Arrays.asList(new Component[]{
                companyImage,companyTitle,  address, tanggalMasukLabel, borderTop, packageName, packageAnswerName
                ,idLabel, createLabel(""+nota.getId(), new Font("Times New Roman", Font.TRUETYPE_FONT,
                16), Color.BLACK),createLabel("Harga : ", new Font("Times New Roman", Font.TRUETYPE_FONT,
                16), Color.BLACK),createLabel(nota.calculateHarga()+"", new Font("Times New Roman", Font.TRUETYPE_FONT,
                16), Color.BLACK),  createLabel("Tanggal terima : ", new Font("Times New Roman", Font.TRUETYPE_FONT,
                16), Color.BLACK), createLabel(nota.getTanggal(), new Font("Times New Roman", Font.TRUETYPE_FONT,
                16), Color.BLACK),createLabel("Estimasi selesai : ", new Font("Times New Roman", Font.TRUETYPE_FONT,
                16), Color.BLACK), createLabel(tanggalKeluar.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")), new Font("Times New Roman", Font.TRUETYPE_FONT,
                16), Color.BLACK), serviceListPanel,servicesLabel, createLabel("Kompensasi: ",new Font("Times New Roman", Font.TRUETYPE_FONT,
                        16), Color.BLACK), createLabel(
                                nota.getSisaHariPengerjaan() < 0 ? String.format("%d",nota.getSisaHariPengerjaan()* 2000) : "-",new Font("Times New Roman", Font.TRUETYPE_FONT,
                        16), Color.BLACK ),createLabel("• • • • • • • • • • • • • • • • • • • • • • •", new
                Font("Montserrat", Font.TRUETYPE_FONT, 22), new Color(172, 188, 255)),createLabel("Harga akhir : ",new Font("Times New Roman", Font.TRUETYPE_FONT,
                16), Color.BLACK ), createLabel(nota.calculateHarga()+"",new Font("Times New Roman", Font.BOLD,
                16), Color.BLACK ), buttonMelengkung
        }));


        this.setLocationRelativeTo(null);
      //  this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        buildFrame(components);
    }
    private String extractService(LaundryService[] services){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<html>");
        for(LaundryService element : services){
            if(element instanceof AntarService || element instanceof SetrikaService){
                stringBuilder.append("+   "+element.getServiceName() +"<br>");
            }
        }
        stringBuilder.append("</html>");
        return stringBuilder.toString();
    }
    private JLabel createLabelImage(String image,int x, int y){
        Image imageObj = new ImageIcon(image).getImage();
        Image resizedImage = imageObj.getScaledInstance(x,y,Image.SCALE_SMOOTH);
        JLabel label = new JLabel(new ImageIcon(resizedImage));
        return label;

    }
    private JLabel createLabel(String text, Font font,  Color color){
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(color);
        return  label;
    }
    private void buildFrame(List<Component> list){
        int i = 0;
        int j = 0;

        for(Component component : list){


            if(0<=i && i <=4){

                this.panel.add(component, new GridBagConstraints(0,i,2,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
                j++;
                if(j >= 4) j = 0;
            }

            else if(i == 5 ){

                this.panel.add(component,new GridBagConstraints(0,5,1,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
                //this.panel.add(component);
            }
            else if(i == 6){
                this.panel.add(component,new GridBagConstraints(1,5,1,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else if(i == 7){
                this.panel.add(component,new GridBagConstraints(0,6,1,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else  if(i == 8){
                this.panel.add(component,new GridBagConstraints(1,6,1,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else  if(i == 9){
                this.panel.add(component,new GridBagConstraints(0,7,1,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else if(i == 10){
                this.panel.add(component,new GridBagConstraints(1,7,1,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else if(i == 11){
                this.panel.add(component,new GridBagConstraints(0,8,1,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else  if(i == 12){
                this.panel.add(component,new GridBagConstraints(1,8,1,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else if(i==13){
                this.panel.add(component,new GridBagConstraints(0,9,1,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else if(i==14){
                this.panel.add(component,new GridBagConstraints(1,9,1,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else  if(i==15){
                this.panel.add(component,new GridBagConstraints(0,10,2,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else if(i==16){
                this.panel.add(component,new GridBagConstraints(0,11,1,2,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else if(i==17){
                this.panel.add(component,new GridBagConstraints(0,13,1,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else if(i==18){
                this.panel.add(component,new GridBagConstraints(1,13,1,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else if(i==19){
                this.panel.add(component,new GridBagConstraints(0,14,2,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else if(i == 20){
                this.panel.add(component,new GridBagConstraints(0,15,1,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else if(i == 21){
                this.panel.add(component,new GridBagConstraints(1,15,1,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(5,20,5,20),0,0));
            }
            else if(i==22){
                this.panel.add(component, new GridBagConstraints(0,16,2,1,0,0,GridBagConstraints.CENTER,
                        GridBagConstraints.NONE,new Insets(15,20,5,20),0,0));
            }

            i++;

        }
    }

}

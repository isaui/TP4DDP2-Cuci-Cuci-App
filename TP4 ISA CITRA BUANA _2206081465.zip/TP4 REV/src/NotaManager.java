import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;

public class NotaManager {

    // field
    public static SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy");
    public static Calendar cal = Calendar.getInstance();
    static public Nota[] notaList = new Nota[2];
    protected static int notaCounter = 0;

    /**
     * Skips ke hari berikutnya dan update semua entri nota yang sesuai.
     */
    /*
     * set tanggal menjadi tanggal selanjutnya, kemudian
     * update setiap nota yang terdapat di notaList
     * */
    public static void toNextDay(){
        cal.add(Calendar.DATE,1);
        for(int i = 0; i < notaCounter; i++){
            notaList[i].toNextDay();
        }

    }

    /**
     * Menambahkan nota baru ke NotaList.
     *
     * @param nota Nota object untuk ditambahkan.
     */

    /*
     * Menambahkan suatu nota ke notaList. Apabila array notaList penuh
     *  maka perlu dilakukan array doubling sebelum menambahkan nota.
     *  Tidak lupa untuk melakukan increment terhadap notaCounter
     * untuk menjaga track berapa jumlah nota yang tersimpan di notaList sekarang
     * */
    public static void addNota(Nota nota){
        if(notaCounter == notaList.length) notaList = Arrays.copyOf(notaList, notaList.length * 2);
        notaList[notaCounter++] = nota;
    }
}

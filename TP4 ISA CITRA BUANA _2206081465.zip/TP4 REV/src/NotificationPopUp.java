import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/*
* Kelas yang menampilkan notification pop up
*  ketika employee melakukan pekerjaan laundry*/
public class NotificationPopUp extends JPanel {
    private JDialog dialog;
    private JLabel label, labelClose;


    private final int DURATION = 2000;
    public NotificationPopUp(String text){
        this.setLayout(new GridBagLayout());
        label = new JLabel(text);
        this.setBackground(new Color(152, 238, 204));
        JPanel panel = new JPanel();
        this.add(panel, new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.WEST,GridBagConstraints.NONE,
                new Insets(0,0,0,10),0,0));
        panel.add(label);
        panel.setPreferredSize(new Dimension(300,50));
        panel.setOpaque(false);
        panel.setVisible(true);
        label.setFont(new Font("Segoe UI", Font.BOLD, 20));
        dialog = new JDialog();
        labelClose = new JLabel("X");
        labelClose.setFont(new Font("Montserrat", Font.TRUETYPE_FONT, 30));
        panel = new JPanel();
        panel.setVisible(true);
        panel.setOpaque(false);
        this.add(panel, new GridBagConstraints(1,0,1,1,0,0, GridBagConstraints.EAST, GridBagConstraints.NONE,
                new Insets(0,0,0,0), 0,0));
        dialog.setContentPane(this);
        dialog.setUndecorated(true);
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        int positionX = dimension.height/2 + 110 + dialog.getWidth();
        int positionY = 40;
        this.setMinimumSize(new Dimension(450,50));
        this.setPreferredSize(new Dimension(450,50));
        dialog.setLocation(positionX,positionY);
        Timer timer = new Timer(DURATION, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        timer.setRepeats(false);
        timer.start();
        this.setVisible(true);
        dialog.setVisible(true);
        dialog.pack();
    }
}

import javax.swing.*;
import javax.swing.plaf.basic.BasicOptionPaneUI;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


/*
* Kelas yang digunakan untuk menampilkan pop up dialog.
*  Hal tersebut berfungsi sebagai reaksi sistem dalam menanggapi input pengguna*/
public class OptionPaneCustom extends JOptionPane {
    private static final Font FONT = new Font("Segoe UI", Font.TRUETYPE_FONT, 16);
    private static final Color BACKGROUND_COLOR = new Color(29,38,125);
    private static  final ImageIcon ERROR_ICON = new ImageIcon("error-icon.png");
    private static final  ImageIcon ACCEPTED_ICON = new ImageIcon("accepted-icon.png");
    private static  final  ImageIcon ASK_ICON = new ImageIcon("ask-icon.png");

    private  static  final Color TEXT_COLOR = Color.white;

    public static void showErrorDialogRev(String title, String message){
        message = "<html><div width=\"300px\"><p align=\"justify\">"+message+"</p></div><html>";
        JLabel label = new JLabel(message);
        LoginPage.ButtonMelengkung buttonMelengkung = new LoginPage.ButtonMelengkung(30,50,"Okay");
        buttonMelengkung.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Window window = SwingUtilities.getWindowAncestor(buttonMelengkung);
                window.dispose();
            }
        });
        buttonMelengkung.setOpaque(false);
        buttonMelengkung.setBackground(new Color(212,172,252));
        JOptionPane pane = new JOptionPane( label, JOptionPane.ERROR_MESSAGE,DEFAULT_OPTION,null,new Object[]
                {buttonMelengkung} );
        pane.setIcon(ERROR_ICON);
        label.setFont(FONT);
        label.setForeground(Color.BLACK);
        //UIManager.put("OptionPane.background", Color.BLACK);
        //UIManager.put("OptionPane.messagebackground", Color.BLACK);

        JDialog dialog = pane.createDialog(null,title);
        dialog.setVisible(true);
    }
    public  static void showAcceptedDialogRev(String title, String message){
        message = "<html><div width=\"300px\"><p align=\"justify\">"+message+"</p></div><html>";
        JLabel label = new JLabel(message);
        LoginPage.ButtonMelengkung buttonMelengkung = new LoginPage.ButtonMelengkung(30,50,"Okay");
        buttonMelengkung.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Window window = SwingUtilities.getWindowAncestor(buttonMelengkung);
                window.dispose();
            }
        });
        buttonMelengkung.setOpaque(false);
        buttonMelengkung.setBackground(new Color(212,172,252));
        JOptionPane pane = new JOptionPane( label,JOptionPane.INFORMATION_MESSAGE,DEFAULT_OPTION,null,new Object[]
                {buttonMelengkung} );
        pane.setIcon(ACCEPTED_ICON);
        label.setFont(FONT);
        label.setForeground(Color.BLACK);

        JDialog dialog = pane.createDialog(null,title);
        dialog.setVisible(true);
    }
    public static void askDialogRev(String title, String message,
                                    MouseListener firstListener, MouseListener secondListener, String firstString,
                                    String secondString){
        message = "<html><div width=\"300px\"><p align=\"justify\">"+message+"</p></div><html>";
        JLabel label = new JLabel(message);
        LoginPage.ButtonMelengkung firstButton = new LoginPage.ButtonMelengkung(30,50,firstString);
        LoginPage.ButtonMelengkung secondButton = new LoginPage.ButtonMelengkung(30,50,secondString);
        firstButton.setOpaque(false);
        secondButton.setOpaque(false);
        firstButton.setPreferredSize(new Dimension(120,30));
        secondButton.setPreferredSize(new Dimension(120,30));
        firstButton.setBackground(new Color(212,172,252));
        secondButton.setBackground(new Color(212,172,252));
        firstButton.addMouseListener(firstListener);
        secondButton.addMouseListener(secondListener);
        JOptionPane pane = new JOptionPane( label, JOptionPane.QUESTION_MESSAGE,YES_NO_OPTION,null,new Object[]
                {firstButton,secondButton} );
        pane.setIcon(ASK_ICON);
        label.setFont(FONT);
        label.setForeground(Color.BLACK);
        JDialog dialog = pane.createDialog(null,title);
        dialog.setVisible(true);
    }

}

public class RegisterData {
    private  final String JOIN_AS;
    private  final String FIRST_NAME;
    private  final String LAST_NAME;
    private  final  String EMAIL_ADDRESS;
    private final String HOME_ADDRESS;
    private  final  String PREFERRED_CONTACT_NUMBER;
    private final String PASSWORD;

    public RegisterData(String JOIN_AS, String FIRST_NAME, String LAST_NAME,
                        String EMAIL_ADDRESS, String HOME_ADDRESS, String PREFERRED_CONTACT_NUMBER, String PASSWORD) {
        this.JOIN_AS = JOIN_AS;
        this.FIRST_NAME = FIRST_NAME;
        this.LAST_NAME = LAST_NAME;
        this.EMAIL_ADDRESS = EMAIL_ADDRESS;
        this.HOME_ADDRESS = HOME_ADDRESS;
        this.PREFERRED_CONTACT_NUMBER = PREFERRED_CONTACT_NUMBER;
        this.PASSWORD = PASSWORD;
    }

    public String getJOIN_AS() {
        return JOIN_AS;
    }

    public String getFIRST_NAME() {
        return FIRST_NAME;
    }

    public String getLAST_NAME() {
        return LAST_NAME;
    }

    public String getEMAIL_ADDRESS() {
        return EMAIL_ADDRESS;
    }

    public String getHOME_ADDRESS() {
        return HOME_ADDRESS;
    }

    public String getPASSWORD() {
        return PASSWORD;
    }

    public String getPREFERRED_CONTACT_NUMBER() {
        return PREFERRED_CONTACT_NUMBER;
    }
}

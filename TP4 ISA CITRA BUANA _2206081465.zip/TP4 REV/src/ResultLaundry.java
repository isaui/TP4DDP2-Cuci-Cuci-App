import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/*
* Frame result setiap kali melakukan satu sesi
* kerjakan semua nota*/
public class ResultLaundry extends JFrame {
    private JScrollPane scrollPane;
    private JPanel mainPanel;
    private JLabel label;
    private String stringFix;
    private LoginPage.ButtonMelengkung button;
    public ResultLaundry(String labelStr){
        this.setLayout(new GridBagLayout());
        this.setSize(new Dimension(800,600));
        this.mainPanel = new JPanel();
        this.scrollPane = new JScrollPane(mainPanel);
        this.scrollPane.setPreferredSize(new Dimension(500,450));
        this.scrollPane.setOpaque(false);
        this.scrollPane.setVisible(true);
        this.mainPanel.setOpaque(false);
        this.mainPanel.setVisible(true);
        this.stringFix = "<html><p>"+labelStr+"</p></html>";
        label = new JLabel(this.stringFix);
        this.mainPanel.add(label);
        this.add(scrollPane);
        this.setVisible(true);
        button = new LoginPage.ButtonMelengkung(30,50,"Okay");
        button.setOpaque(false);
        button.setForeground(Color.white);
        button.setBackground(new Color(29,38,125));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose();
            }
        });
        this.label.setBackground(new Color(212,172,252));
        this.setLocationRelativeTo(null);
        this.add(scrollPane, new GridBagConstraints(0,0,1,1,
                0,0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,
                new Insets(0,0,20,0), 0,0));
        this.add(button, new GridBagConstraints(0,1,1,1
                ,0,0,GridBagConstraints.CENTER,GridBagConstraints.NONE,
                new Insets(0,0,20,0), 0,0));
    }
}

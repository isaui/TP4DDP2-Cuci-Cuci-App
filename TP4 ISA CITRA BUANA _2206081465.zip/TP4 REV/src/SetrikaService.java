public class SetrikaService implements LaundryService{
    private  boolean done; // field
    @Override
    public String doWork() {
        // TODO
        this.done = true; // set done ke true karena service ini ditandai selesai dikerjakan
        return "Sedang menyetrika...";
    }

    // getter field isDone
    @Override
    public boolean isDone() {
        return this.done;
    }

    // harga service setrika = 1000 per kilogram
    @Override
    public long getHarga(int berat) {
        return 1000 * berat;
    }

    // dapatkan nama service
    @Override
    public String getServiceName() {
        return "Setrika";
    }
}


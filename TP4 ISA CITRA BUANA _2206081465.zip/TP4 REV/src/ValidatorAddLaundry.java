import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/*
* Kelas yang digunakan untuk memvalidasi
* penambahan permintaan (nota) laundry apakah valid atau tidak*/
public class ValidatorAddLaundry {
    private boolean tambahSetrika, tambahPengiriman;
    private  Member member;
    private String namaPaket, tanggalMasuk;
    private String beratStr;
    private boolean valid = true;
    private  int berat;
    public
    ValidatorAddLaundry(
            Member member, String namaPaket, String  berat,
            String tanggalMasuk, boolean tambahSetrika, boolean tambahPengiriman){
        this.member = member;
        this.namaPaket = namaPaket;
        this.beratStr = berat;
        this.tanggalMasuk = tanggalMasuk;
        this.tambahSetrika = tambahSetrika;
        this.tambahPengiriman = tambahPengiriman;
    }
    public Nota createValidNota(){
        if(berat < 2) OptionPaneCustom.askDialogRev("Attention", "The weight of your laundry" +
                " is less than 2 kg. Would you like " +
                "to continue with the order by assuming a " +
                "weight of 2 kg?", new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // ini menolak
                valid = false;
                Window window = SwingUtilities.getWindowAncestor(e.getComponent());
                System.out.println("mouselistener1");
                window.dispose();
            }
        }, new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                berat = berat < 2? 2 : berat;
                Window window = SwingUtilities.getWindowAncestor(e.getComponent());
                window.dispose();
            }
        },"Change weight", "Continue with 2 Kg" );
        if(!valid ) return null;

        Nota nota = new Nota(member,berat,namaPaket, tanggalMasuk);
        System.out.println("nota created!!!!");
        if(tambahSetrika)nota.addService(new SetrikaService());
        if(tambahPengiriman)nota.addService(new AntarService());
        System.out.println(nota.calculateHarga());

        return nota;
    }
    public boolean cekValidasi(){
        if(beratStr.chars().allMatch(Character::isDigit) && !beratStr.isEmpty()){
            berat = Integer.parseInt(beratStr);
            return true;
        }
        return false;

    }
}

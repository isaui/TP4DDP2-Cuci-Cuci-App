public class ValidatorLogin {
    /*
    * Memvalidasi login user apakah valid atau tidak.
    *  Jika ya maka akan diarahkan ke menu aplikasi*/

    private  String id;
    private String password;
    private SystemCLI systemCLI;
    public ValidatorLogin(String id, String password, SystemCLI systemCLI){
        this.id = id;
        this.password = password;
        this.systemCLI = systemCLI;
    }
    public Member requestLogin(){
        if(systemCLI == null) return  null;
        Member member = systemCLI.authUser(this.id,this.password);
        return member;
    }
}

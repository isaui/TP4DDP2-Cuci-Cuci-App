public class ValidatorRegister {
    /*
    * Melakukan validasi ketika register. Kelas ini memiliki konstruktor
    *  yang digunakan untuk menghimpun data registrasi user.
    *  Jika valid maka user ditambahkan, jika tidak maka
    * program akan meminta user memasukkan data yag valid*/

    private boolean isValid;
    private boolean isMember;
    private RegisterPanel.Column nameColumn, telephoneColumn, passwordColumn, passwordSameColumn, lastNameColumn;
    public ValidatorRegister(RegisterPanel.Column nameColumn, RegisterPanel.Column lastNameColumn,RegisterPanel.Column telephoneColumn, RegisterPanel.Column
                             passwordColumn, RegisterPanel.Column passwordSameColumn, boolean isMember){
        this.isMember = isMember;
        this.nameColumn = nameColumn;
        this.lastNameColumn = lastNameColumn;
        this.telephoneColumn = telephoneColumn;
        this.passwordColumn = passwordColumn;
        this.passwordSameColumn = passwordSameColumn;
        if(nameColumn.textField.getText().isEmpty() && (
                telephoneColumn.textField.getText().isEmpty() ||
                        !telephoneColumn.textField.getText().chars().allMatch(Character::isDigit))){
            OptionPaneCustom.showErrorDialogRev("Register Failed", "Data was not entered correctly. Please enter a valid name and phone number.");
        }
        else if(nameColumn.textField.getText().isEmpty()){
            OptionPaneCustom.showErrorDialogRev("Register Failed", "Data was not entered correctly." +
                    " Please enter a valid name.");
        }
        else if(!telephoneColumn.textField.getText().chars().allMatch(Character::isDigit) || telephoneColumn.textField.getText().isEmpty()
        ){
            OptionPaneCustom.showErrorDialogRev("Register Failed", "Data was not entered correctly." +
                    " Please enter a valid telephone number.");
        } else if (!passwordColumn.textField.getText().equals(passwordSameColumn.textField.getText())) {
            OptionPaneCustom.showErrorDialogRev("Register Failed",
                    "Incorrect data input. The entered passwords do not match");
        } else if (passwordColumn.textField.getText().isEmpty() || passwordSameColumn.textField.getText().isEmpty()) {
            OptionPaneCustom.showErrorDialogRev("Register Failed",
                    "Incorrect data input. The entered passwords is empty");
        } else {
            isValid = true;
        }
    }
    public Member register(){
        if(!isValid) return  null;
        if(isMember){
            Member member = MainMenu.getInstance().getLoginManager().register(this.nameColumn.textField.getText()+" "+lastNameColumn.textField.getText()
                , this.telephoneColumn.textField.getText(),
                this.passwordColumn.textField.getText());
            if(member == null){
                OptionPaneCustom.showErrorDialogRev("Register Failed",
                    "Member with same name and id has already registered");
            }
            return member;
        }
        else {
            Member member = MainMenu.getInstance().getLoginManager().registerAsEmployee(
                    this.nameColumn.textField.getText()+this.lastNameColumn.textField.getText(), this.telephoneColumn.textField.getText(),
                    this.passwordColumn.textField.getText()
            );
            if(member == null) OptionPaneCustom.showErrorDialogRev("Register Failed",
                    "Employee with same name has already registered");
            return  member;
        }
    }

}
